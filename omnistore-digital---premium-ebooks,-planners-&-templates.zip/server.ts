import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import { db } from './src/server/db.js';
import {
  generateJazzCashSecureHash,
  verifyJazzCashCallback,
  calculateCryptoAmount,
  generateSvgQrCode
} from './src/server/payments.js';
import { STORAGE_DIR } from './src/server/sample-files.js';
import { CryptoCurrency } from './src/types.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_SECRET_TOKEN = 'omni_admin_session_key_2026';

// Middleware for body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper admin auth middleware (Password requirement removed as requested)
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  return next();
}

// -----------------------------------------------------------------------------
// PUBLIC STORE APIS
// -----------------------------------------------------------------------------

// Get all published products
app.get('/api/products', (req: Request, res: Response) => {
  const products = db.getProducts(false);
  res.json({ products });
});

// Get single product
app.get('/api/products/:id', (req: Request, res: Response) => {
  const product = db.getProductById(req.params.id) || db.getProductBySlug(req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json({ product });
});

// Get store public settings
app.get('/api/settings/public', (req: Request, res: Response) => {
  const s = db.getSettings();
  res.json({
    storeName: s.storeName,
    supportEmail: s.supportEmail,
    defaultCurrency: s.defaultCurrency,
    usdToPkrRate: s.usdToPkrRate,
    jazzcashSandbox: s.jazzcash.environment === 'sandbox',
    cryptoSandbox: s.crypto.environment === 'sandbox',
    supportedCryptoCurrencies: ['USDT_TRC20', 'BTC', 'ETH', 'SOL'],
    jazzcashNumber: s.jazzcash.merchantMobileNumber || '03001234567',
    jazzcashTitle: s.jazzcash.accountTitle || 'OmniStore Digital Merchant',
    easypaisaEnabled: s.easypaisa?.enabled ?? true,
    easypaisaNumber: s.easypaisa?.mobileNumber || '03451234567',
    easypaisaTitle: s.easypaisa?.accountTitle || 'OmniStore Digital Merchant'
  });
});

// Create checkout order
app.post('/api/orders/create', (req: Request, res: Response) => {
  const { customerEmail, customerName, customerPhone, productId, currency, paymentMethod } = req.body;

  if (!customerEmail || !productId) {
    return res.status(400).json({ error: 'Customer email and product are required' });
  }

  const product = db.getProductById(productId);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const selectedCurrency = currency === 'PKR' ? 'PKR' : 'USD';
  const amount = selectedCurrency === 'PKR' ? product.pricePKR : product.priceUSD;

  const order = db.createOrder({
    customerEmail,
    customerName: customerName || customerEmail.split('@')[0],
    customerPhone,
    productId: product.id,
    productTitle: product.title,
    amount,
    currency: selectedCurrency,
    paymentMethod: paymentMethod === 'crypto' ? 'crypto' : 'jazzcash',
    paymentStatus: 'pending'
  });

  res.json({ order });
});

// Get order status
app.get('/api/orders/:id', (req: Request, res: Response) => {
  const order = db.getOrderById(req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json({ order });
});

// Customer order tracking / lookup
app.get('/api/orders/lookup/search', (req: Request, res: Response) => {
  const query = (req.query.q as string || '').trim();
  if (!query) {
    return res.status(400).json({ error: 'Please enter an Order ID or Email address' });
  }

  if (query.toUpperCase().startsWith('ORD-')) {
    const order = db.getOrderById(query.toUpperCase());
    return res.json({ orders: order ? [order] : [] });
  }

  const orders = db.findOrdersByEmail(query);
  res.json({ orders });
});

// -----------------------------------------------------------------------------
// JAZZCASH PAYMENT GATEWAY
// -----------------------------------------------------------------------------

// Initiate JazzCash Hosted Checkout
app.post('/api/payments/jazzcash/initiate', (req: Request, res: Response) => {
  const { orderId, paymentMode = 'MWALLET', mobileNumber } = req.body;
  const order = db.getOrderById(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = db.getSettings();
  const jc = settings.jazzcash;

  // Convert amount to PKR paisa string if required by JazzCash spec (or rupees depending on merchant category)
  // For standard merchant portal: pp_Amount is in paisas (e.g. 500.00 -> 50000) or rupees format.
  const amountStr = (order.amount * 100).toString();
  const txnDateTime = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14);
  const txnRefNo = 'T' + Date.now();

  const params: Record<string, string> = {
    pp_Version: '1.1',
    pp_TxnType: paymentMode === 'CARD' ? 'MPAY' : 'MWALLET',
    pp_Language: 'EN',
    pp_MerchantID: jc.merchantId,
    pp_SubMerchantID: '',
    pp_Password: jc.password,
    pp_BankID: 'TBANK',
    pp_ProductID: order.productId,
    pp_TxnRefNo: txnRefNo,
    pp_Amount: amountStr,
    pp_TxnCurrency: 'PKR',
    pp_TxnDateTime: txnDateTime,
    pp_BillReference: order.id,
    pp_Description: `Purchase of ${order.productTitle.slice(0, 50)}`,
    pp_TxnExpiryDateTime: new Date(Date.now() + 3600 * 1000).toISOString().replace(/[-:T.Z]/g, '').slice(0, 14),
    pp_ReturnURL: jc.returnUrl || '/api/payments/jazzcash/callback'
  };

  if (mobileNumber && paymentMode === 'MWALLET') {
    params.pp_MobileNumber = mobileNumber;
  }

  // Generate cryptographic hash using integrity salt
  const secureHash = generateJazzCashSecureHash(params, jc.integritySalt);
  params.pp_SecureHash = secureHash;

  // Update order with tentative details
  db.updateOrder(order.id, {
    paymentGatewayRef: txnRefNo,
    jazzcashDetails: {
      pp_TxnRefNo: txnRefNo,
      pp_Amount: amountStr,
      pp_TxnCurrency: 'PKR',
      pp_ResponseCode: 'Pending',
      pp_ResponseMessage: 'Initiated checkout',
      paymentMode,
      mobileNumber
    }
  });

  const gatewayPostUrl = jc.environment === 'live'
    ? 'https://payments.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/'
    : 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/';

  res.json({
    postUrl: gatewayPostUrl,
    params,
    isSandbox: jc.environment === 'sandbox',
    merchantMobileNumber: jc.merchantMobileNumber || '03001234567',
    accountTitle: jc.accountTitle || 'OmniStore Digital Merchant',
    easypaisaNumber: settings.easypaisa?.mobileNumber || '03451234567',
    easypaisaTitle: settings.easypaisa?.accountTitle || 'OmniStore Digital Merchant'
  });
});

// Official JazzCash Gateway Webhook / Return URL Callback
app.all('/api/payments/jazzcash/callback', (req: Request, res: Response) => {
  const payload = { ...req.query, ...req.body } as Record<string, string>;
  const orderId = payload['pp_BillReference'] || payload['orderId'];
  const responseCode = payload['pp_ResponseCode'];
  const txnRef = payload['pp_TxnRefNo'];

  if (!orderId) {
    return res.status(400).send('Missing order reference');
  }

  const order = db.getOrderById(orderId);
  if (!order) {
    return res.status(404).send('Order not found');
  }

  const settings = db.getSettings();
  const isValidHash = verifyJazzCashCallback(payload, settings.jazzcash.integritySalt);

  // In sandbox environment or if hash matches
  const isApproved = (responseCode === '000' || responseCode === '121' || responseCode === 'SUCCESS') &&
    (isValidHash || settings.jazzcash.environment === 'sandbox');

  if (isApproved) {
    db.markOrderAsPaid(order.id, txnRef, {
      pp_TxnRefNo: txnRef,
      pp_ResponseCode: responseCode || '000',
      pp_ResponseMessage: payload['pp_ResponseMessage'] || 'Transaction Verified and Paid',
      paymentMode: order.jazzcashDetails?.paymentMode || 'MWALLET'
    });

    if (req.method === 'GET') {
      // Redirect to storefront with completed order query
      return res.redirect(`/?order_success=${order.id}`);
    }
    return res.json({ success: true, message: 'Payment verified and order fulfilled' });
  }

  // Payment failed
  db.updateOrder(order.id, {
    paymentStatus: 'failed',
    jazzcashDetails: {
      ...order.jazzcashDetails,
      pp_ResponseCode: responseCode || '999',
      pp_ResponseMessage: payload['pp_ResponseMessage'] || 'Payment failed or declined'
    } as any
  });

  if (req.method === 'GET') {
    return res.redirect(`/?order_failed=${order.id}`);
  }
  return res.status(400).json({ success: false, error: 'Payment declined or invalid signature' });
});

// Test mode: Simulated JazzCash gateway verification
app.post('/api/payments/jazzcash/simulate-verify', (req: Request, res: Response) => {
  const { orderId, pin, mobileNumber, trxId } = req.body;
  const order = db.getOrderById(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const txnRef = trxId ? `TID-${trxId.toUpperCase().replace(/\s+/g, '')}` : ('JC-SIM-' + Math.floor(100000 + Math.random() * 900000));
  const updatedOrder = db.markOrderAsPaid(order.id, txnRef, {
    pp_TxnRefNo: txnRef,
    pp_Amount: (order.amount * 100).toString(),
    pp_TxnCurrency: 'PKR',
    pp_ResponseCode: '000',
    pp_ResponseMessage: trxId ? `Manual Transfer Verified (TID: ${trxId})` : 'Transaction Approved via JazzCash Gateway',
    paymentMode: order.jazzcashDetails?.paymentMode || 'MWALLET',
    mobileNumber: mobileNumber || order.customerPhone || '03001234567'
  });

  res.json({
    success: true,
    message: 'JazzCash payment confirmed and verified',
    order: updatedOrder
  });
});

// -----------------------------------------------------------------------------
// CRYPTOCURRENCY PAYMENTS
// -----------------------------------------------------------------------------

// Create Crypto Invoice
app.post('/api/payments/crypto/create-invoice', (req: Request, res: Response) => {
  const { orderId, cryptoCurrency = 'USDT_TRC20' } = req.body;
  const order = db.getOrderById(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = db.getSettings();
  const cSettings = settings.crypto;

  // Select destination wallet address from settings
  let walletAddress = cSettings.usdtWallet;
  if (cryptoCurrency === 'BTC') walletAddress = cSettings.btcWallet;
  else if (cryptoCurrency === 'ETH') walletAddress = cSettings.ethWallet;
  else if (cryptoCurrency === 'SOL') walletAddress = cSettings.solWallet;

  // Calculate USD amount if order was in PKR
  const amountUSD = order.currency === 'USD'
    ? order.amount
    : Number((order.amount / settings.usdToPkrRate).toFixed(2));

  const cryptoAmount = calculateCryptoAmount(amountUSD, cryptoCurrency as CryptoCurrency);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 minutes invoice window
  const requiredConfirmations = cryptoCurrency === 'BTC' ? 2 : (cryptoCurrency === 'ETH' ? 6 : 1);

  // Generate SVG QR Code for wallet address
  const qrSvg = generateSvgQrCode(walletAddress);

  const cryptoDetails = {
    cryptoCurrency: cryptoCurrency as CryptoCurrency,
    cryptoAmount,
    walletAddress,
    confirmations: 0,
    requiredConfirmations,
    expiresAt,
    status: 'waiting' as const
  };

  const updatedOrder = db.updateOrder(order.id, {
    cryptoDetails,
    paymentGatewayRef: `CRYPTO-${cryptoCurrency}-${Date.now()}`
  });

  res.json({
    order: updatedOrder,
    cryptoDetails,
    qrSvg,
    isSandbox: cSettings.environment === 'sandbox'
  });
});

// Poll Crypto Payment Status
app.get('/api/payments/crypto/status/:orderId', (req: Request, res: Response) => {
  const order = db.getOrderById(req.params.orderId);
  if (!order || !order.cryptoDetails) {
    return res.status(404).json({ error: 'Invoice not found' });
  }

  const isExpired = new Date() > new Date(order.cryptoDetails.expiresAt) && order.paymentStatus !== 'paid';
  if (isExpired && order.cryptoDetails.status !== 'expired') {
    db.updateOrder(order.id, {
      paymentStatus: 'failed',
      cryptoDetails: { ...order.cryptoDetails, status: 'expired' }
    });
  }

  res.json({
    paymentStatus: order.paymentStatus,
    cryptoDetails: order.cryptoDetails,
    downloadToken: order.paymentStatus === 'paid' ? order.downloadToken : undefined
  });
});

// Incoming Crypto Webhook (e.g. NOWPayments / BTCPay)
app.post('/api/payments/crypto/webhook', (req: Request, res: Response) => {
  const settings = db.getSettings();
  const signature = req.headers['x-nowpayments-sig'] as string;
  const { payment_id, payment_status, order_id, actually_paid, pay_currency } = req.body;

  // Webhook security verification
  if (settings.crypto.environment === 'live') {
    if (!signature) {
      return res.status(401).json({ error: 'Missing webhook signature' });
    }
    const hmac = crypto.createHmac('sha512', settings.crypto.ipnSecret);
    hmac.update(JSON.stringify(req.body));
    const digest = hmac.digest('hex');
    if (signature !== digest) {
      return res.status(401).json({ error: 'Invalid HMAC signature' });
    }
  }

  if (!order_id) {
    return res.status(400).json({ error: 'Missing order_id' });
  }

  const order = db.getOrderById(order_id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  // Prevent releasing if status is not finished or verified
  if (payment_status === 'finished' || payment_status === 'confirmed') {
    db.markOrderAsPaid(order.id, `NP-${payment_id}`, {
      status: 'finished',
      confirmations: 10,
      txHash: `tx_${crypto.randomBytes(16).toString('hex')}`
    });
    return res.json({ success: true, message: 'Payment confirmed & download issued' });
  }

  if (payment_status === 'failed' || payment_status === 'expired') {
    db.updateOrder(order.id, {
      paymentStatus: 'failed',
      cryptoDetails: {
        ...order.cryptoDetails!,
        status: payment_status
      }
    });
  }

  res.json({ received: true });
});

// Test mode: Simulate blockchain network confirmation blocks
app.post('/api/payments/crypto/simulate-confirm', (req: Request, res: Response) => {
  const { orderId } = req.body;
  const order = db.getOrderById(orderId);
  if (!order || !order.cryptoDetails) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const current = order.cryptoDetails.confirmations || 0;
  const required = order.cryptoDetails.requiredConfirmations || 1;
  const nextConfirmations = current + 1;

  if (nextConfirmations >= required) {
    // Verified and confirmed!
    const txHash = '0x' + crypto.randomBytes(32).toString('hex');
    const updated = db.markOrderAsPaid(order.id, `TX-${txHash.slice(0, 10)}`, {
      confirmations: nextConfirmations,
      txHash,
      status: 'finished'
    });
    return res.json({
      status: 'finished',
      confirmations: nextConfirmations,
      requiredConfirmations: required,
      isPaid: true,
      order: updated
    });
  } else {
    const updated = db.updateOrder(order.id, {
      cryptoDetails: {
        ...order.cryptoDetails,
        confirmations: nextConfirmations,
        status: 'confirming'
      }
    });
    return res.json({
      status: 'confirming',
      confirmations: nextConfirmations,
      requiredConfirmations: required,
      isPaid: false,
      order: updated
    });
  }
});

// -----------------------------------------------------------------------------
// AUTOMATIC PDF SECURE DELIVERY & PRIVATE STORAGE
// -----------------------------------------------------------------------------

// Download info check
app.get('/api/downloads/info/:token', (req: Request, res: Response) => {
  const { token } = req.params;
  const order = db.getOrderByToken(token);
  if (!order) {
    return res.status(404).json({ error: 'Invalid or unknown download token' });
  }

  if (order.paymentStatus !== 'paid') {
    return res.status(403).json({ error: 'Payment is not verified yet. File access is restricted.' });
  }

  const isExpired = new Date() > new Date(order.downloadExpiresAt);
  const isLimitReached = order.downloadCount >= order.maxDownloads;
  const product = db.getProductById(order.productId);

  res.json({
    orderId: order.id,
    productTitle: order.productTitle,
    fileName: product?.fileName || 'digital-product.pdf',
    fileSize: product?.fileSize || 'Unknown',
    fileFormat: product?.fileFormat || 'PDF',
    downloadsUsed: order.downloadCount,
    maxDownloads: order.maxDownloads,
    expiresAt: order.downloadExpiresAt,
    isExpired,
    isLimitReached,
    canDownload: !isExpired && !isLimitReached
  });
});

// Stream private PDF file with strict access control
app.get('/api/downloads/:token', (req: Request, res: Response) => {
  const { token } = req.params;
  const order = db.getOrderByToken(token);

  if (!order) {
    return res.status(404).send('Invalid download token. Access denied.');
  }

  // 1. Payment verification check
  if (order.paymentStatus !== 'paid') {
    return res.status(403).send('Unauthorized. Payment must be verified before digital product release.');
  }

  // 2. Expiration check
  if (new Date() > new Date(order.downloadExpiresAt)) {
    return res.status(403).send('Download link has expired. Please contact support to request a link extension.');
  }

  // 3. Download count limit check
  if (order.downloadCount >= order.maxDownloads) {
    return res.status(403).send(`Download limit exceeded (${order.maxDownloads} downloads limit reached).`);
  }

  const product = db.getProductById(order.productId);
  const targetFileName = product?.fileName || 'Executive_Life_Planner_2026.pdf';
  const filePath = path.join(STORAGE_DIR, targetFileName);

  if (!fs.existsSync(filePath)) {
    // If not found on disk, attempt fallback to first available file in storage
    const files = fs.readdirSync(STORAGE_DIR);
    if (files.length === 0) {
      return res.status(500).send('Product file unavailable in secure storage.');
    }
    const fallbackPath = path.join(STORAGE_DIR, files[0]);
    return deliverFile(order, fallbackPath, product?.fileName || files[0], req, res);
  }

  deliverFile(order, filePath, targetFileName, req, res);
});

function deliverFile(order: any, filePath: string, fileName: string, req: Request, res: Response) {
  // Atomically increment download count
  db.updateOrder(order.id, {
    downloadCount: (order.downloadCount || 0) + 1
  });

  const stat = fs.statSync(filePath);
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');

  const fileStream = fs.createReadStream(filePath);
  fileStream.pipe(res);
}

// -----------------------------------------------------------------------------
// CUSTOMER SUPPORT & REFUNDS
// -----------------------------------------------------------------------------

app.post('/api/support/ticket', (req: Request, res: Response) => {
  const { orderId, customerEmail, type, subject, message } = req.body;
  if (!orderId || !customerEmail || !message) {
    return res.status(400).json({ error: 'Order ID, customer email, and message are required' });
  }

  const ticket = db.createSupportTicket({
    orderId,
    customerEmail,
    type: type || 'general_question',
    subject: subject || 'Support Request',
    message
  });

  res.json({ success: true, ticket });
});

// -----------------------------------------------------------------------------
// SECURE ADMIN DASHBOARD APIS
// -----------------------------------------------------------------------------

// Admin login (Password requirement removed)
app.post('/api/admin/login', (req: Request, res: Response) => {
  return res.json({
    success: true,
    token: ADMIN_SECRET_TOKEN,
    user: { role: 'super_admin', email: 'khansab6734@gmail.com' }
  });
});

// Analytics & sales report
app.get('/api/admin/analytics', requireAdmin, (req: Request, res: Response) => {
  const report = db.getSalesReport();
  res.json({ report });
});

// Get all products (including unpublished)
app.get('/api/admin/products', requireAdmin, (req: Request, res: Response) => {
  const products = db.getProducts(true);
  res.json({ products });
});

// Upsert product
app.post('/api/admin/products', requireAdmin, (req: Request, res: Response) => {
  const productData = req.body;
  if (!productData.title || !productData.priceUSD || !productData.pricePKR) {
    return res.status(400).json({ error: 'Title, Price (USD), and Price (PKR) are required' });
  }
  const product = db.upsertProduct(productData);
  res.json({ success: true, product });
});

// Delete product
app.delete('/api/admin/products/:id', requireAdmin, (req: Request, res: Response) => {
  const success = db.deleteProduct(req.params.id);
  res.json({ success });
});

// Upload digital PDF / product file into private storage
app.post('/api/admin/upload-file', requireAdmin, (req: Request, res: Response) => {
  const { fileName, base64Content } = req.body;
  if (!fileName || !base64Content) {
    return res.status(400).json({ error: 'File name and base64 content are required' });
  }

  const safeFileName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  const targetPath = path.join(STORAGE_DIR, safeFileName);
  const buffer = Buffer.from(base64Content.replace(/^data:.*?;base64,/, ''), 'base64');

  fs.writeFileSync(targetPath, buffer);

  const stats = fs.statSync(targetPath);
  const sizeMB = (stats.size / (1024 * 1024)).toFixed(1) + ' MB';

  res.json({
    success: true,
    fileName: safeFileName,
    fileSize: sizeMB,
    fileFormat: path.extname(safeFileName).toUpperCase().replace('.', '') || 'PDF'
  });
});

// Upload cover image
app.post('/api/admin/upload-cover', requireAdmin, (req: Request, res: Response) => {
  const { fileName, base64Content } = req.body;
  if (!fileName || !base64Content) {
    return res.status(400).json({ error: 'File name and base64 content are required' });
  }

  const imagesDir = path.resolve(process.cwd(), 'src', 'assets', 'images');
  if (!fs.existsSync(imagesDir)) {
    fs.mkdirSync(imagesDir, { recursive: true });
  }

  const safeName = `cover_${Date.now()}_` + fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  const targetPath = path.join(imagesDir, safeName);
  const buffer = Buffer.from(base64Content.replace(/^data:.*?;base64,/, ''), 'base64');

  fs.writeFileSync(targetPath, buffer);

  res.json({
    success: true,
    url: `/src/assets/images/${safeName}`
  });
});

// Get orders list
app.get('/api/admin/orders', requireAdmin, (req: Request, res: Response) => {
  const orders = db.getOrders();
  res.json({ orders });
});

// Manual payment verification (Admin override)
app.post('/api/admin/orders/:id/verify-paid', requireAdmin, (req: Request, res: Response) => {
  const order = db.markOrderAsPaid(req.params.id, `MANUAL-VERIFY-${Date.now()}`, {
    pp_ResponseMessage: 'Manually verified and confirmed by Administrator'
  });
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json({ success: true, order });
});

// Process Refund
app.post('/api/admin/orders/:id/refund', requireAdmin, (req: Request, res: Response) => {
  const { reason } = req.body;
  const order = db.updateOrder(req.params.id, {
    paymentStatus: 'refunded',
    refundedAt: new Date().toISOString(),
    refundReason: reason || 'Customer requested refund'
  });
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json({ success: true, order });
});

// Reissue or Extend Download Token
app.post('/api/admin/orders/:id/reissue-token', requireAdmin, (req: Request, res: Response) => {
  const { extensionHours = 72, resetCount = true } = req.body;
  const order = db.getOrderById(req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const newToken = 'tok_' + crypto.randomBytes(20).toString('hex');
  const newExpiry = new Date(Date.now() + extensionHours * 3600 * 1000).toISOString();

  const updated = db.updateOrder(order.id, {
    downloadToken: newToken,
    downloadExpiresAt: newExpiry,
    downloadCount: resetCount ? 0 : order.downloadCount
  });

  res.json({ success: true, order: updated });
});

// Support tickets list
app.get('/api/admin/tickets', requireAdmin, (req: Request, res: Response) => {
  const tickets = db.getSupportTickets();
  res.json({ tickets });
});

// Update support ticket
app.post('/api/admin/tickets/:id', requireAdmin, (req: Request, res: Response) => {
  const { status, adminNotes } = req.body;
  const updated = db.updateSupportTicket(req.params.id, { status, adminNotes });
  if (!updated) {
    return res.status(404).json({ error: 'Ticket not found' });
  }
  res.json({ success: true, ticket: updated });
});

// Get store settings
app.get('/api/admin/settings', requireAdmin, (req: Request, res: Response) => {
  const settings = db.getSettings();
  res.json({ settings });
});

// Update store settings
app.post('/api/admin/settings', requireAdmin, (req: Request, res: Response) => {
  const updated = db.updateSettings(req.body);
  res.json({ success: true, settings: updated });
});

// Email outbox
app.get('/api/admin/emails', requireAdmin, (req: Request, res: Response) => {
  const emails = db.getEmailLogs();
  res.json({ emails });
});

// Resend confirmation email
app.post('/api/admin/emails/resend/:id', requireAdmin, (req: Request, res: Response) => {
  const email = db.getEmailLogs().find(e => e.id === req.params.id);
  if (!email) {
    return res.status(404).json({ error: 'Email record not found' });
  }
  const order = db.getOrderById(email.orderId);
  if (!order) {
    return res.status(404).json({ error: 'Associated order not found' });
  }
  const sent = db.sendConfirmationEmail(order);
  res.json({ success: true, email: sent });
});

// -----------------------------------------------------------------------------
// VITE MIDDLEWARE / STATIC ASSETS
// -----------------------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[OmniStore Digital] Server listening on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
