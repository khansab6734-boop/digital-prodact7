export type Currency = 'PKR' | 'USD';

export type ProductCategory =
  | 'Planners & Journals'
  | 'eBooks & Handbooks'
  | 'Productivity & Notion'
  | 'Developer & Tech'
  | 'Templates & Bundles';

export interface Product {
  id: string;
  title: string;
  slug: string;
  tagline: string;
  description: string;
  category: ProductCategory;
  priceUSD: number;
  pricePKR: number;
  coverImage: string;
  previewImages?: string[];
  fileName: string;
  fileSize: string;
  fileFormat: string;
  pagesCount: number;
  whatsIncluded: string[];
  features: string[];
  isPublished: boolean;
  downloadsCount: number;
  rating: number;
  reviewsCount: number;
  createdAt: string;
  updatedAt: string;
}

export type PaymentMethod = 'jazzcash' | 'crypto';
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded';

export interface JazzCashDetails {
  pp_TxnRefNo: string;
  pp_Amount: string;
  pp_TxnCurrency: string;
  pp_ResponseCode: string;
  pp_ResponseMessage: string;
  paymentMode: 'MWALLET' | 'CARD' | 'VOUCHER';
  mobileNumber?: string;
  verifiedAt?: string;
}

export type CryptoCurrency = 'USDT_TRC20' | 'BTC' | 'ETH' | 'SOL';

export interface CryptoDetails {
  cryptoCurrency: CryptoCurrency;
  cryptoAmount: number;
  walletAddress: string;
  txHash?: string;
  confirmations: number;
  requiredConfirmations: number;
  expiresAt: string;
  status: 'waiting' | 'confirming' | 'finished' | 'expired' | 'failed';
}

export interface Order {
  id: string;
  customerEmail: string;
  customerName: string;
  customerPhone?: string;
  productId: string;
  productTitle: string;
  amount: number;
  currency: Currency;
  paymentMethod: PaymentMethod;
  paymentGatewayRef?: string;
  paymentStatus: PaymentStatus;
  jazzcashDetails?: JazzCashDetails;
  cryptoDetails?: CryptoDetails;
  downloadToken: string;
  downloadExpiresAt: string;
  downloadCount: number;
  maxDownloads: number;
  createdAt: string;
  paidAt?: string;
  refundedAt?: string;
  refundReason?: string;
}

export interface SupportTicket {
  id: string;
  orderId: string;
  customerEmail: string;
  type: 'refund_request' | 'download_issue' | 'general_question';
  subject: string;
  message: string;
  status: 'open' | 'resolved' | 'rejected';
  adminNotes?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface StoreSettings {
  storeName: string;
  supportEmail: string;
  defaultCurrency: Currency;
  usdToPkrRate: number;
  downloadLinkExpiryHours: number;
  maxDownloadLimit: number;
  jazzcash: {
    merchantMobileNumber: string;
    accountTitle: string;
    merchantId: string;
    password: string;
    integritySalt: string;
    returnUrl: string;
    environment: 'sandbox' | 'live';
    sandboxAutoApproveAvailable: boolean;
  };
  easypaisa?: {
    enabled: boolean;
    mobileNumber: string;
    accountTitle: string;
  };
  bankTransfer?: {
    enabled: boolean;
    bankName: string;
    accountTitle: string;
    accountNumber: string;
    iban: string;
  };
  crypto: {
    provider: 'NOWPayments' | 'BTCPay' | 'DirectWallet';
    apiKey: string;
    ipnSecret: string;
    usdtWallet: string;
    btcWallet: string;
    ethWallet: string;
    solWallet: string;
    environment: 'sandbox' | 'live';
  };
}

export interface EmailLog {
  id: string;
  orderId: string;
  recipientEmail: string;
  subject: string;
  htmlContent: string;
  downloadUrl: string;
  sentAt: string;
  status: 'sent' | 'delivered';
}

export interface SalesReport {
  totalRevenueUSD: number;
  totalRevenuePKR: number;
  totalPaidOrders: number;
  totalDownloadsDelivered: number;
  conversionRate: number;
  jazzcashRevenuePKR: number;
  cryptoRevenueUSD: number;
  recentSales: { date: string; amountUSD: number; amountPKR: number; count: number }[];
  topProducts: { id: string; title: string; count: number; revenueUSD: number }[];
}
