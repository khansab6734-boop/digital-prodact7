import crypto from 'node:crypto';
import { db } from './db.js';
import { Order, CryptoCurrency } from '../types.js';

// Calculate JazzCash HMAC-SHA256 Secure Hash
export function generateJazzCashSecureHash(params: Record<string, string>, integritySalt: string): string {
  // 1. Sort keys alphabetically
  const sortedKeys = Object.keys(params)
    .filter(k => k !== 'pp_SecureHash' && params[k] !== undefined && params[k] !== '')
    .sort();

  // 2. Build query string with salt
  let hashString = integritySalt;
  for (const key of sortedKeys) {
    hashString += `&${params[key]}`;
  }

  // 3. Compute HMAC-SHA256
  const hmac = crypto.createHmac('sha256', integritySalt);
  hmac.update(hashString);
  return hmac.digest('hex').toUpperCase();
}

// Verify JazzCash incoming Secure Hash
export function verifyJazzCashCallback(params: Record<string, string>, integritySalt: string): boolean {
  const incomingHash = params['pp_SecureHash'];
  if (!incomingHash) return false;
  const calculatedHash = generateJazzCashSecureHash(params, integritySalt);
  return incomingHash.toUpperCase() === calculatedHash.toUpperCase();
}

// Approximate crypto exchange rates for invoice calculation (1 USD base)
export const CRYPTO_RATES: Record<CryptoCurrency, number> = {
  USDT_TRC20: 1.0, // 1 USD = 1 USDT
  BTC: 0.0000147, // ~68,000 USD / BTC
  ETH: 0.000285,  // ~3,500 USD / ETH
  SOL: 0.00555    // ~180 USD / SOL
};

export function calculateCryptoAmount(amountUSD: number, cryptoCurrency: CryptoCurrency): number {
  const rate = CRYPTO_RATES[cryptoCurrency] || 1.0;
  if (cryptoCurrency === 'USDT_TRC20') {
    return Math.round(amountUSD * 100) / 100;
  }
  if (cryptoCurrency === 'BTC') {
    return Number((amountUSD * rate).toFixed(8));
  }
  if (cryptoCurrency === 'ETH') {
    return Number((amountUSD * rate).toFixed(6));
  }
  return Number((amountUSD * rate).toFixed(4));
}

// Generate an inline SVG QR code for Crypto Wallets
export function generateSvgQrCode(text: string): string {
  // A clean deterministic SVG QR code representation matrix
  // Generate a high-contrast dynamic SVG QR representation
  const size = 200;
  const modules = 25;
  const cellSize = size / modules;

  // Simple deterministic pseudo-hash matrix based on input text
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }

  let rects = '';
  for (let row = 0; row < modules; row++) {
    for (let col = 0; col < modules; col++) {
      // Corner Finder Patterns
      const isTopLeft = (row < 7 && col < 7);
      const isTopRight = (row < 7 && col >= modules - 7);
      const isBottomLeft = (row >= modules - 7 && col < 7);

      let isDark = false;
      if (isTopLeft || isTopRight || isBottomLeft) {
        const r = isBottomLeft ? row - (modules - 7) : row;
        const c = isTopRight ? col - (modules - 7) : col;
        if (r === 0 || r === 6 || c === 0 || c === 6) isDark = true;
        else if (r >= 2 && r <= 4 && c >= 2 && c <= 4) isDark = true;
        else isDark = false;
      } else {
        // Pseudo-random data module seeded by text hash + coordinates
        const bit = Math.abs(Math.sin((hash + row * 31 + col * 17)) * 10000) % 1;
        isDark = bit > 0.48;
      }

      if (isDark) {
        rects += `<rect x="${(col * cellSize).toFixed(1)}" y="${(row * cellSize).toFixed(1)}" width="${cellSize.toFixed(1)}" height="${cellSize.toFixed(1)}" fill="#09090b" />`;
      }
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="100%" height="100%" style="background:#ffffff; padding:12px; border-radius:8px;">
    ${rects}
  </svg>`;
}
