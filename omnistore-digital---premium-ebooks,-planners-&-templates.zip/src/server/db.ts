import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  Product,
  Order,
  SupportTicket,
  StoreSettings,
  EmailLog,
  SalesReport
} from '../types.js';
import { ensureSampleDigitalFiles } from './sample-files.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

interface DatabaseSchema {
  products: Product[];
  orders: Order[];
  supportTickets: SupportTicket[];
  settings: StoreSettings;
  emailLogs: EmailLog[];
}

const defaultSettings: StoreSettings = {
  storeName: 'OmniStore Digital',
  supportEmail: 'support@omnistoredigital.com',
  defaultCurrency: 'USD',
  usdToPkrRate: 278,
  downloadLinkExpiryHours: 48,
  maxDownloadLimit: 5,
  jazzcash: {
    merchantMobileNumber: '03001234567',
    accountTitle: 'OmniStore Digital Merchant',
    merchantId: 'MC12345_TEST',
    password: 'password123',
    integritySalt: '2x99f7831k',
    returnUrl: '/api/payments/jazzcash/callback',
    environment: 'sandbox',
    sandboxAutoApproveAvailable: true
  },
  easypaisa: {
    enabled: true,
    mobileNumber: '03451234567',
    accountTitle: 'OmniStore Digital Merchant'
  },
  bankTransfer: {
    enabled: false,
    bankName: 'Meezan Bank Ltd',
    accountTitle: 'OmniStore Digital',
    accountNumber: '010203040506',
    iban: 'PK36MEZN0001020304050607'
  },
  crypto: {
    provider: 'NOWPayments',
    apiKey: 'SANDBOX_DEMO_KEY_99218',
    ipnSecret: 'DEMO_WEBHOOK_SECRET_88192',
    usdtWallet: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
    btcWallet: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    ethWallet: '0x71C83897F43243576595F5c1A1869E24b22c2a95',
    solWallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
    environment: 'sandbox'
  }
};

const defaultProducts: Product[] = [
  {
    id: 'prod_planner_2026',
    title: 'Executive Life & Habit Planner 2026',
    slug: 'executive-life-planner-2026',
    tagline: 'Hyperlinked digital planning system for iPad & tablets with goal-sprinting modules.',
    description: 'The definitive executive planning system engineered for ambitious founders, operators, and creators. Includes 184 hyperlinked pages, daily time-boxing spreads, quarterly OKR tracking, weekly reviews, and scientific habit formation frameworks. Compatible with GoodNotes, Notability, and Samsung Notes.',
    category: 'Planners & Journals',
    priceUSD: 19,
    pricePKR: 5200,
    coverImage: '/src/assets/images/digital_planner_cover_1792093507305.jpg',
    fileName: 'Executive_Life_Planner_2026.pdf',
    fileSize: '14.2 MB',
    fileFormat: 'PDF (Hyperlinked & Fillable)',
    pagesCount: 184,
    whatsIncluded: [
      'Interactive Hyperlinked PDF (Index + Tab Navigation)',
      'Print-ready high resolution A4 / US Letter files',
      'Daily time-blocking & focus sprint layouts',
      'Bonus: 50+ Custom Digital Sticker Icons'
    ],
    features: [
      'Universal tablet compatibility (GoodNotes, Noteshelf, Remarkable)',
      'Lag-free instant tab index navigation',
      'Quarterly goal alignment & habit streak counters',
      'Undated & 2026 Dated versions included'
    ],
    isPublished: true,
    downloadsCount: 1420,
    rating: 4.9,
    reviewsCount: 128,
    createdAt: '2026-09-01T10:00:00Z',
    updatedAt: '2026-10-10T12:00:00Z'
  },
  {
    id: 'prod_wealth_roadmap',
    title: 'The Modern Wealth Roadmap',
    slug: 'modern-wealth-roadmap-ebook',
    tagline: 'Practical asset allocation, high-yield digital cashflow, and global sovereign banking.',
    description: 'A comprehensive, zero-fluff playbook covering the modern financial playbook. Learn how forward-thinking investors build resilient asymmetric portfolios, establish multi-currency cash flow engines, leverage digital products, and protect wealth against local currency devaluation.',
    category: 'eBooks & Handbooks',
    priceUSD: 29,
    pricePKR: 7990,
    coverImage: '/src/assets/images/fintech_guide_ebook_1792093506939.jpg',
    fileName: 'Wealth_Roadmap_Financial_Guide.pdf',
    fileSize: '8.4 MB',
    fileFormat: 'PDF & EPUB Bundle',
    pagesCount: 220,
    whatsIncluded: [
      'Full eBook in High-DPI PDF & Flowable EPUB',
      'Portfolio Allocation Spreadsheet (Google Sheets & Excel)',
      'Digital Income Stream Financial Modeler',
      'Checklist: International Gateway Setup'
    ],
    features: [
      'Actionable step-by-step case studies with real balance sheets',
      'Strategies for protecting against inflation & devaluation',
      'Cross-border payment infrastructure breakdowns',
      'Lifetime free updates to new editions'
    ],
    isPublished: true,
    downloadsCount: 980,
    rating: 4.8,
    reviewsCount: 89,
    createdAt: '2026-09-15T14:30:00Z',
    updatedAt: '2026-10-12T09:15:00Z'
  },
  {
    id: 'prod_freelance_os',
    title: 'Freelance Operating System & Client Portal',
    slug: 'freelance-os-notion-suite',
    tagline: 'Complete client onboarding, project delivery, and automated retainer billing.',
    description: 'Transform your freelance or agency business into an organized, high-margin machine. Includes an interactive client onboarding portal, dynamic milestone deliverable tracker, proposal & contract templates, and invoice dashboard.',
    category: 'Productivity & Notion',
    priceUSD: 24,
    pricePKR: 6600,
    coverImage: '/src/assets/images/notion_freelance_suite_1792093508641.jpg',
    fileName: 'Freelance_OS_Notion_Guide.pdf',
    fileSize: '11.8 MB',
    fileFormat: 'PDF Guide + 1-Click Notion Template',
    pagesCount: 65,
    whatsIncluded: [
      'One-click Notion Workspace Duplicate Link',
      'Comprehensive PDF Implementation & Setup Manual',
      'Client Onboarding Email Copy Templates',
      'Contract & Statement of Work Legal Boilerplate'
    ],
    features: [
      'Live client sharing with granular view permissions',
      'Automated overdue invoice alerts & retainer trackers',
      'Custom project timeline Gantt & Kanban views',
      'Pre-built resource library for deliverables'
    ],
    isPublished: true,
    downloadsCount: 760,
    rating: 4.9,
    reviewsCount: 74,
    createdAt: '2026-09-20T08:00:00Z',
    updatedAt: '2026-10-14T11:00:00Z'
  },
  {
    id: 'prod_dev_handbook',
    title: 'Modern Distributed System Architecture',
    slug: 'distributed-system-architecture-handbook',
    tagline: 'High-concurrency system designs, microservices failure modes, and API security.',
    description: 'A visual, highly technical manual covering enterprise system design patterns. Features real-world production postmortems, idempotency in payment gateways, distributed database sharding, zero-trust token security, and caching strategies under millions of QPS.',
    category: 'Developer & Tech',
    priceUSD: 34,
    pricePKR: 9400,
    coverImage: '/src/assets/images/developer_handbook_cover_1792093508096.jpg',
    fileName: 'Modern_System_Architecture_Handbook.pdf',
    fileSize: '22.5 MB',
    fileFormat: 'PDF (Vector Diagrams & Print Quality)',
    pagesCount: 310,
    whatsIncluded: [
      '310-Page Color Architecture Handbook (PDF)',
      'Downloadable SVG & Mermaid.js System Diagrams',
      'Production Idempotency Middleware Code Samples',
      'System Design Interview Cheat-Sheet & Matrix'
    ],
    features: [
      'Over 85+ full-color architectural topology diagrams',
      'Deep dives into payment consistency & webhook security',
      'Kafka, Redis & PostgreSQL optimization benchmarks',
      'Authored by senior principal systems engineers'
    ],
    isPublished: true,
    downloadsCount: 1150,
    rating: 5.0,
    reviewsCount: 142,
    createdAt: '2026-09-05T16:00:00Z',
    updatedAt: '2026-10-14T15:20:00Z'
  }
];

const sampleOrders: Order[] = [
  {
    id: 'ORD-2026-78210',
    customerEmail: 'khansab6734@gmail.com',
    customerName: 'Asim Khan',
    customerPhone: '+923001234567',
    productId: 'prod_planner_2026',
    productTitle: 'Executive Life & Habit Planner 2026',
    amount: 5200,
    currency: 'PKR',
    paymentMethod: 'jazzcash',
    paymentGatewayRef: 'JC-TXN-984210',
    paymentStatus: 'paid',
    jazzcashDetails: {
      pp_TxnRefNo: 'T1792091000',
      pp_Amount: '520000',
      pp_TxnCurrency: 'PKR',
      pp_ResponseCode: '000',
      pp_ResponseMessage: 'Transaction Approved',
      paymentMode: 'MWALLET',
      mobileNumber: '03001234567',
      verifiedAt: '2026-10-15T09:20:00Z'
    },
    downloadToken: 'tok_live_7a8b9c1d2e3f4051627384',
    downloadExpiresAt: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
    downloadCount: 2,
    maxDownloads: 5,
    createdAt: '2026-10-15T09:18:00Z',
    paidAt: '2026-10-15T09:20:00Z'
  },
  {
    id: 'ORD-2026-78209',
    customerEmail: 'sarah.miller@enterprise.io',
    customerName: 'Sarah Miller',
    productId: 'prod_dev_handbook',
    productTitle: 'Modern Distributed System Architecture',
    amount: 34,
    currency: 'USD',
    paymentMethod: 'crypto',
    paymentGatewayRef: 'NP-INV-551940',
    paymentStatus: 'paid',
    cryptoDetails: {
      cryptoCurrency: 'USDT_TRC20',
      cryptoAmount: 34,
      walletAddress: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
      txHash: '0x3f5c7e9a1b2d4e6f8a0b1c2d3e4f5a6b7c8d9e0f',
      confirmations: 20,
      requiredConfirmations: 3,
      expiresAt: '2026-10-15T08:30:00Z',
      status: 'finished'
    },
    downloadToken: 'tok_live_bb918273645e4d3c2b1a0f',
    downloadExpiresAt: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
    downloadCount: 1,
    maxDownloads: 5,
    createdAt: '2026-10-15T08:00:00Z',
    paidAt: '2026-10-15T08:05:00Z'
  },
  {
    id: 'ORD-2026-78208',
    customerEmail: 'tariq.aziz@lahoretech.pk',
    customerName: 'Tariq Aziz',
    customerPhone: '+923218765432',
    productId: 'prod_wealth_roadmap',
    productTitle: 'The Modern Wealth Roadmap',
    amount: 7990,
    currency: 'PKR',
    paymentMethod: 'jazzcash',
    paymentGatewayRef: 'JC-TXN-984180',
    paymentStatus: 'paid',
    jazzcashDetails: {
      pp_TxnRefNo: 'T1792090500',
      pp_Amount: '799000',
      pp_TxnCurrency: 'PKR',
      pp_ResponseCode: '000',
      pp_ResponseMessage: 'Transaction Approved',
      paymentMode: 'CARD',
      verifiedAt: '2026-10-14T20:15:00Z'
    },
    downloadToken: 'tok_live_cc192837465f0e1d2c3b4a',
    downloadExpiresAt: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
    downloadCount: 3,
    maxDownloads: 5,
    createdAt: '2026-10-14T20:10:00Z',
    paidAt: '2026-10-14T20:15:00Z'
  }
];

const sampleTickets: SupportTicket[] = [
  {
    id: 'TKT-1001',
    orderId: 'ORD-2026-78210',
    customerEmail: 'khansab6734@gmail.com',
    type: 'download_issue',
    subject: 'Request to open in GoodNotes',
    message: 'Hello, the PDF downloaded flawlessly! Is there any tip for importing the bonus sticker collection into GoodNotes 6? Thank you!',
    status: 'resolved',
    adminNotes: 'Advised customer to unzip bonus stickers into Files app and drag directly into Elements panel.',
    createdAt: '2026-10-15T10:00:00Z',
    resolvedAt: '2026-10-15T10:15:00Z'
  }
];

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDir();
    ensureSampleDigitalFiles();
    this.data = this.load();
  }

  private ensureDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          products: parsed.products || defaultProducts,
          orders: parsed.orders || sampleOrders,
          supportTickets: parsed.supportTickets || sampleTickets,
          settings: {
            ...defaultSettings,
            ...(parsed.settings || {}),
            jazzcash: { ...defaultSettings.jazzcash, ...(parsed.settings?.jazzcash || {}) },
            easypaisa: { ...(defaultSettings.easypaisa || {}), ...(parsed.settings?.easypaisa || {}) },
            crypto: { ...defaultSettings.crypto, ...(parsed.settings?.crypto || {}) }
          },
          emailLogs: parsed.emailLogs || []
        };
      } catch (err) {
        console.error('Failed to parse db.json, reinitializing default data:', err);
      }
    }
    const initial: DatabaseSchema = {
      products: defaultProducts,
      orders: sampleOrders,
      supportTickets: sampleTickets,
      settings: defaultSettings,
      emailLogs: []
    };
    this.saveDirect(initial);
    return initial;
  }

  private saveDirect(data: DatabaseSchema) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  }

  public persist() {
    this.saveDirect(this.data);
  }

  // Products
  public getProducts(includeUnpublished = false): Product[] {
    if (includeUnpublished) return [...this.data.products];
    return this.data.products.filter(p => p.isPublished);
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find(p => p.id === id);
  }

  public getProductBySlug(slug: string): Product | undefined {
    return this.data.products.find(p => p.slug === slug);
  }

  public upsertProduct(product: Partial<Product> & { title: string; priceUSD: number; pricePKR: number }): Product {
    const existingIndex = product.id ? this.data.products.findIndex(p => p.id === product.id) : -1;
    const now = new Date().toISOString();

    if (existingIndex >= 0) {
      const updated: Product = {
        ...this.data.products[existingIndex],
        ...product,
        updatedAt: now
      };
      this.data.products[existingIndex] = updated;
      this.persist();
      return updated;
    } else {
      const newProduct: Product = {
        id: product.id || 'prod_' + crypto.randomBytes(6).toString('hex'),
        title: product.title,
        slug: product.slug || product.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        tagline: product.tagline || 'High-quality digital product.',
        description: product.description || '',
        category: product.category || 'eBooks & Handbooks',
        priceUSD: Number(product.priceUSD),
        pricePKR: Number(product.pricePKR),
        coverImage: product.coverImage || '/src/assets/images/digital_planner_cover_1792093507305.jpg',
        fileName: product.fileName || 'Digital_Product.pdf',
        fileSize: product.fileSize || '5.0 MB',
        fileFormat: product.fileFormat || 'PDF',
        pagesCount: product.pagesCount || 50,
        whatsIncluded: product.whatsIncluded || ['Full Digital PDF Download'],
        features: product.features || ['Instant Download', 'Lifetime Access'],
        isPublished: product.isPublished !== undefined ? product.isPublished : true,
        downloadsCount: 0,
        rating: 5.0,
        reviewsCount: 1,
        createdAt: now,
        updatedAt: now
      };
      this.data.products.unshift(newProduct);
      this.persist();
      return newProduct;
    }
  }

  public deleteProduct(id: string): boolean {
    const prevLen = this.data.products.length;
    this.data.products = this.data.products.filter(p => p.id !== id);
    if (this.data.products.length !== prevLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // Orders
  public getOrders(): Order[] {
    return [...this.data.orders];
  }

  public getOrderById(id: string): Order | undefined {
    return this.data.orders.find(o => o.id === id);
  }

  public getOrderByToken(token: string): Order | undefined {
    return this.data.orders.find(o => o.downloadToken === token);
  }

  public findOrdersByEmail(email: string): Order[] {
    return this.data.orders.filter(o => o.customerEmail.toLowerCase() === email.toLowerCase());
  }

  public createOrder(orderData: Omit<Order, 'id' | 'downloadToken' | 'downloadExpiresAt' | 'downloadCount' | 'maxDownloads' | 'createdAt'>): Order {
    const settings = this.getSettings();
    const token = 'tok_' + crypto.randomBytes(20).toString('hex');
    const orderId = 'ORD-' + new Date().getFullYear() + '-' + Math.floor(10000 + Math.random() * 90000);
    const expiresAt = new Date(Date.now() + (settings.downloadLinkExpiryHours || 48) * 3600 * 1000).toISOString();

    const order: Order = {
      ...orderData,
      id: orderId,
      downloadToken: token,
      downloadExpiresAt: expiresAt,
      downloadCount: 0,
      maxDownloads: settings.maxDownloadLimit || 5,
      createdAt: new Date().toISOString()
    };

    this.data.orders.unshift(order);
    this.persist();
    return order;
  }

  public updateOrder(orderId: string, updates: Partial<Order>): Order | undefined {
    const idx = this.data.orders.findIndex(o => o.id === orderId);
    if (idx < 0) return undefined;
    const updated = { ...this.data.orders[idx], ...updates };
    this.data.orders[idx] = updated;
    this.persist();
    return updated;
  }

  public markOrderAsPaid(orderId: string, gatewayRef?: string, details?: any): Order | undefined {
    const order = this.getOrderById(orderId);
    if (!order) return undefined;

    // Prevent duplicate fulfillment
    if (order.paymentStatus === 'paid') {
      return order;
    }

    const updates: Partial<Order> = {
      paymentStatus: 'paid',
      paidAt: new Date().toISOString(),
      paymentGatewayRef: gatewayRef || order.paymentGatewayRef
    };

    if (order.paymentMethod === 'jazzcash' && details) {
      updates.jazzcashDetails = {
        ...order.jazzcashDetails,
        ...details,
        verifiedAt: new Date().toISOString()
      };
    } else if (order.paymentMethod === 'crypto' && details) {
      updates.cryptoDetails = {
        ...order.cryptoDetails,
        ...details,
        status: 'finished'
      };
    }

    const updated = this.updateOrder(orderId, updates);

    // Increment product download counter
    const prod = this.getProductById(order.productId);
    if (prod) {
      prod.downloadsCount += 1;
      this.persist();
    }

    // Trigger confirmation email logging
    if (updated) {
      this.sendConfirmationEmail(updated);
    }

    return updated;
  }

  public sendConfirmationEmail(order: Order): EmailLog {
    const settings = this.getSettings();
    const downloadUrl = `/api/downloads/${order.downloadToken}`;
    const subject = `Your Digital Download: ${order.productTitle} (${order.id})`;
    
    const htmlContent = `
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #18181b; background-color: #ffffff; border: 1px solid #e4e4e7; border-radius: 8px;">
        <h2 style="margin-top: 0; color: #09090b;">Payment Confirmed! Here is your download link</h2>
        <p>Dear ${order.customerName || 'Customer'},</p>
        <p>Thank you for purchasing <strong>${order.productTitle}</strong> from ${settings.storeName}. Your payment of <strong>${order.currency === 'PKR' ? 'Rs ' + order.amount.toLocaleString() : '$' + order.amount.toFixed(2)}</strong> via <strong>${order.paymentMethod.toUpperCase()}</strong> has been securely verified.</p>
        
        <div style="margin: 28px 0; text-align: center;">
          <a href="${downloadUrl}" style="background-color: #0f172a; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
            Download Your Digital PDF
          </a>
        </div>

        <div style="background-color: #f4f4f5; padding: 16px; border-radius: 6px; font-size: 13px; color: #52525b; margin-bottom: 20px;">
          <p style="margin: 0 0 6px 0;"><strong>Order Number:</strong> ${order.id}</p>
          <p style="margin: 0 0 6px 0;"><strong>Download Limit:</strong> ${order.maxDownloads} downloads allowed</p>
          <p style="margin: 0 0 6px 0;"><strong>Link Expiration:</strong> Valid for 48 hours</p>
          <p style="margin: 0;"><strong>Need Assistance?</strong> Contact us at ${settings.supportEmail}</p>
        </div>

        <p style="font-size: 12px; color: #a1a1aa; margin: 0;">
          OmniStore Digital · Automated Digital Delivery Engine · Please keep this receipt for your records.
        </p>
      </div>
    `;

    const emailLog: EmailLog = {
      id: 'eml_' + crypto.randomBytes(8).toString('hex'),
      orderId: order.id,
      recipientEmail: order.customerEmail,
      subject,
      htmlContent,
      downloadUrl,
      sentAt: new Date().toISOString(),
      status: 'delivered'
    };

    this.data.emailLogs.unshift(emailLog);
    this.persist();
    return emailLog;
  }

  // Support Tickets
  public getSupportTickets(): SupportTicket[] {
    return [...this.data.supportTickets];
  }

  public createSupportTicket(ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>): SupportTicket {
    const newTicket: SupportTicket = {
      ...ticket,
      id: 'TKT-' + Math.floor(1000 + Math.random() * 9000),
      status: 'open',
      createdAt: new Date().toISOString()
    };
    this.data.supportTickets.unshift(newTicket);
    this.persist();
    return newTicket;
  }

  public updateSupportTicket(id: string, updates: Partial<SupportTicket>): SupportTicket | undefined {
    const idx = this.data.supportTickets.findIndex(t => t.id === id);
    if (idx < 0) return undefined;
    const updated = { ...this.data.supportTickets[idx], ...updates };
    if (updates.status === 'resolved' && !this.data.supportTickets[idx].resolvedAt) {
      updated.resolvedAt = new Date().toISOString();
    }
    this.data.supportTickets[idx] = updated;
    this.persist();
    return updated;
  }

  // Settings
  public getSettings(): StoreSettings {
    return { ...this.data.settings };
  }

  public updateSettings(newSettings: Partial<StoreSettings>): StoreSettings {
    this.data.settings = {
      ...this.data.settings,
      ...newSettings,
      jazzcash: {
        ...this.data.settings.jazzcash,
        ...(newSettings.jazzcash || {})
      },
      easypaisa: {
        ...(this.data.settings.easypaisa || defaultSettings.easypaisa!),
        ...(newSettings.easypaisa || {})
      },
      bankTransfer: {
        ...(this.data.settings.bankTransfer || defaultSettings.bankTransfer!),
        ...(newSettings.bankTransfer || {})
      },
      crypto: {
        ...this.data.settings.crypto,
        ...(newSettings.crypto || {})
      }
    };
    this.persist();
    return this.getSettings();
  }

  // Email Logs
  public getEmailLogs(): EmailLog[] {
    return [...this.data.emailLogs];
  }

  // Sales Analytics
  public getSalesReport(): SalesReport {
    const paidOrders = this.data.orders.filter(o => o.paymentStatus === 'paid');
    
    let totalRevenueUSD = 0;
    let totalRevenuePKR = 0;
    let jazzcashRevenuePKR = 0;
    let cryptoRevenueUSD = 0;
    let totalDownloads = 0;

    const rate = this.data.settings.usdToPkrRate || 278;
    const productSalesMap: Record<string, { title: string; count: number; revenueUSD: number }> = {};

    for (const o of paidOrders) {
      if (o.currency === 'PKR') {
        totalRevenuePKR += o.amount;
        totalRevenueUSD += o.amount / rate;
      } else {
        totalRevenueUSD += o.amount;
        totalRevenuePKR += o.amount * rate;
      }

      if (o.paymentMethod === 'jazzcash') {
        jazzcashRevenuePKR += o.currency === 'PKR' ? o.amount : o.amount * rate;
      } else {
        cryptoRevenueUSD += o.currency === 'USD' ? o.amount : o.amount / rate;
      }

      totalDownloads += o.downloadCount || 0;

      if (!productSalesMap[o.productId]) {
        productSalesMap[o.productId] = { title: o.productTitle, count: 0, revenueUSD: 0 };
      }
      productSalesMap[o.productId].count += 1;
      productSalesMap[o.productId].revenueUSD += o.currency === 'USD' ? o.amount : o.amount / rate;
    }

    const conversionRate = this.data.orders.length > 0
      ? Number(((paidOrders.length / this.data.orders.length) * 100).toFixed(1))
      : 0;

    const topProducts = Object.entries(productSalesMap).map(([id, info]) => ({
      id,
      title: info.title,
      count: info.count,
      revenueUSD: Math.round(info.revenueUSD)
    })).sort((a, b) => b.count - a.count);

    // Recent 7 days breakdown
    const recentSales: { date: string; amountUSD: number; amountPKR: number; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayOrders = paidOrders.filter(o => o.createdAt.startsWith(dateStr));
      let dayUSD = 0;
      let dayPKR = 0;
      dayOrders.forEach(o => {
        if (o.currency === 'USD') {
          dayUSD += o.amount;
          dayPKR += o.amount * rate;
        } else {
          dayPKR += o.amount;
          dayUSD += o.amount / rate;
        }
      });
      recentSales.push({
        date: dateStr,
        amountUSD: Math.round(dayUSD),
        amountPKR: Math.round(dayPKR),
        count: dayOrders.length
      });
    }

    return {
      totalRevenueUSD: Math.round(totalRevenueUSD),
      totalRevenuePKR: Math.round(totalRevenuePKR),
      totalPaidOrders: paidOrders.length,
      totalDownloadsDelivered: totalDownloads,
      conversionRate,
      jazzcashRevenuePKR: Math.round(jazzcashRevenuePKR),
      cryptoRevenueUSD: Math.round(cryptoRevenueUSD),
      recentSales,
      topProducts
    };
  }
}

export const db = new Database();
