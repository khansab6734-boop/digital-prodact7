import fs from 'node:fs';
import path from 'node:path';

export const STORAGE_DIR = path.resolve(process.cwd(), 'storage', 'digital_files');

// Helper to construct a real, valid PDF document buffer with text
function createSimplePdfBuffer(title: string, subtitle: string, sections: { heading: string; content: string }[]): Buffer {
  let contentStream = `BT\n/F1 20 Tf\n50 750 Td\n(${escapePdfText(title)}) Tj\nET\n`;
  contentStream += `BT\n/F2 12 Tf\n50 725 Td\n(${escapePdfText(subtitle)}) Tj\nET\n`;
  contentStream += `BT\n/F2 9 Tf\n50 705 Td\n(Licensed to Verified Purchaser · OmniStore Digital · Unauthorized Distribution Prohibited) Tj\nET\n`;

  let y = 665;
  for (const sec of sections) {
    if (y < 120) break;
    contentStream += `BT\n/F1 13 Tf\n50 ${y} Td\n(${escapePdfText(sec.heading)}) Tj\nET\n`;
    y -= 20;

    // split content into lines
    const words = sec.content.split(' ');
    let currentLine = '';
    for (const word of words) {
      if ((currentLine + ' ' + word).length > 80) {
        contentStream += `BT\n/F2 10 Tf\n50 ${y} Td\n(${escapePdfText(currentLine.trim())}) Tj\nET\n`;
        y -= 15;
        currentLine = word;
      } else {
        currentLine = (currentLine + ' ' + word).trim();
      }
    }
    if (currentLine) {
      contentStream += `BT\n/F2 10 Tf\n50 ${y} Td\n(${escapePdfText(currentLine.trim())}) Tj\nET\n`;
      y -= 25;
    }
  }

  const streamLength = Buffer.byteLength(contentStream, 'utf-8');

  const pdf = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>
endobj
4 0 obj
<< /Length ${streamLength} >>
stream
${contentStream}
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>
endobj
6 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 7
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000244 00000 n 
0000000000 00000 n 
0000000000 00000 n 
trailer
<< /Size 7 /Root 1 0 R >>
startxref
${400 + streamLength}
%%EOF`;

  return Buffer.from(pdf, 'utf-8');
}

function escapePdfText(text: string): string {
  return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

export function ensureSampleDigitalFiles(): void {
  if (!fs.existsSync(STORAGE_DIR)) {
    fs.mkdirSync(STORAGE_DIR, { recursive: true });
  }

  const sampleFiles = [
    {
      fileName: 'Executive_Life_Planner_2026.pdf',
      title: 'Executive Life & Habit Planner 2026',
      subtitle: 'Complete 184-Page Interactive System for High Achievers',
      sections: [
        {
          heading: 'Chapter 1: The Annual Vision Framework',
          content: 'Set non-negotiable yearly milestones, break them down into 90-day sprints, and identify your foundational high-leverage habits.'
        },
        {
          heading: 'Chapter 2: Daily Focus & Time Block Architecture',
          content: 'Eliminate cognitive overload with structured daily prompts: Top 3 needle movers, energy tracking, and evening reflection.'
        },
        {
          heading: 'Chapter 3: Habit Streak & Momentum Tracking',
          content: 'Science-backed habit tracking grids designed to compound small daily wins into massive transformational breakthroughs.'
        }
      ]
    },
    {
      fileName: 'Wealth_Roadmap_Financial_Guide.pdf',
      title: 'The Modern Wealth Roadmap',
      subtitle: 'Asset Allocation, High-Yield Portfolios & Digital Cashflow',
      sections: [
        {
          heading: 'Section 1: Asymmetric Risk & Portfolio Construction',
          content: 'How top capital allocators safeguard wealth while capturing exponential upside in digital and decentralized markets.'
        },
        {
          heading: 'Section 2: Cashflow Engines & Digital Products',
          content: 'Step-by-step blueprints for engineering zero-marginal-cost digital assets that generate continuous global income.'
        },
        {
          heading: 'Section 3: Global Banking, Taxation & Compliance',
          content: 'Practical frameworks for structuring international merchant gateways, multi-currency accounts, and tax efficiency.'
        }
      ]
    },
    {
      fileName: 'Freelance_OS_Notion_Guide.pdf',
      title: 'Freelance Operating System & Client Portal',
      subtitle: 'Production Ready Notion Architecture + Standard Operating Procedures',
      sections: [
        {
          heading: 'Module 1: High-Conversion Client Onboarding Flow',
          content: 'Automated intake questionnaires, scope agreement templates, and professional welcome packets that establish immediate authority.'
        },
        {
          heading: 'Module 2: Project Milestones & Deliverables Tracker',
          content: 'Real-time collaborative dashboards allowing clients to review assets, approve design phases, and track timeline progress without endless emails.'
        },
        {
          heading: 'Module 3: Invoicing, Retainers & Contract Repository',
          content: 'Seamless billing trackers, payment receipts log, and contract protection clauses for freelancers and boutique agencies.'
        }
      ]
    },
    {
      fileName: 'Modern_System_Architecture_Handbook.pdf',
      title: 'Modern Distributed System Architecture',
      subtitle: 'High-Concurrency Patterns, Resilient Microservices & API Gateways',
      sections: [
        {
          heading: 'Architecture Principle 1: Idempotency & Distributed Transactions',
          content: 'Designing bulletproof payment pipelines with cryptographic idempotency keys, write-ahead logs, and two-phase commit fallbacks.'
        },
        {
          heading: 'Architecture Principle 2: Event-Driven Scaling with Kafka & Redis',
          content: 'Decoupling compute-heavy workflows via asynchronous message queues, consumer worker groups, and partition management.'
        },
        {
          heading: 'Architecture Principle 3: Zero-Trust Security & API Hardening',
          content: 'Implementing strict token rotation, HMAC request signature verification, rate limiting, and private storage isolation.'
        }
      ]
    }
  ];

  for (const item of sampleFiles) {
    const filePath = path.join(STORAGE_DIR, item.fileName);
    if (!fs.existsSync(filePath)) {
      const buffer = createSimplePdfBuffer(item.title, item.subtitle, item.sections);
      fs.writeFileSync(filePath, buffer);
    }
  }
}
