import React, { useState, useEffect } from 'react';
import { Product, Order, Currency, ProductCategory } from './types.js';
import { Header } from './components/Header.js';
import { Hero } from './components/Hero.js';
import { ProductCard } from './components/ProductCard.js';
import { ProductDetailModal } from './components/ProductDetailModal.js';
import { CheckoutModal } from './components/CheckoutModal.js';
import { JazzCashPaymentModal } from './components/JazzCashPaymentModal.js';
import { CryptoPaymentModal } from './components/CryptoPaymentModal.js';
import { OrderConfirmationModal } from './components/OrderConfirmationModal.js';
import { OrderTrackerModal } from './components/OrderTrackerModal.js';
import { SupportModal } from './components/SupportModal.js';
import { AdminDashboard } from './components/AdminDashboard.js';
import { SetupGuideModal } from './components/SetupGuideModal.js';
import { ShieldCheck, RefreshCw, Smartphone, Globe, Lock, FileText, ArrowRight, BookOpen } from 'lucide-react';

const CATEGORIES: ProductCategory[] = [
  'Planners & Journals',
  'eBooks & Handbooks',
  'Productivity & Notion',
  'Developer & Tech',
  'Templates & Bundles'
];

export default function App() {
  const [currency, setCurrency] = useState<Currency>('USD');
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Modal active states
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [showJazzCashModal, setShowJazzCashModal] = useState(false);
  const [showCryptoModal, setShowCryptoModal] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [showTrackerModal, setShowTrackerModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [supportInitialOrderId, setSupportInitialOrderId] = useState('');
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showSetupGuideModal, setShowSetupGuideModal] = useState(false);

  // Fetch products
  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      if (data.products) {
        setProducts(data.products);
      }
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();

    // Check if returning from gateway redirect (?order_success=ORD-XXXX)
    const urlParams = new URLSearchParams(window.location.search);
    const successOrderId = urlParams.get('order_success');
    if (successOrderId) {
      fetch(`/api/orders/${successOrderId}`)
        .then((r) => r.json())
        .then((d) => {
          if (d.order) {
            setConfirmedOrder(d.order);
            // clean url without refresh
            window.history.replaceState({}, document.title, window.location.pathname);
          }
        })
        .catch(console.error);
    }
  }, []);

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    if (selectedCategory !== 'All' && p.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = p.title.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      const matchTagline = p.tagline.toLowerCase().includes(q);
      const matchCategory = p.category.toLowerCase().includes(q);
      return matchTitle || matchDesc || matchTagline || matchCategory;
    }
    return true;
  });

  // Handle Checkout creation transition
  const handleOrderCreated = (order: Order) => {
    setCheckoutProduct(null);
    setCurrentOrder(order);
    if (order.paymentMethod === 'jazzcash') {
      setShowJazzCashModal(true);
    } else {
      setShowCryptoModal(true);
    }
  };

  // Handle Payment Success
  const handlePaymentSuccess = (paidOrder: Order) => {
    setShowJazzCashModal(false);
    setShowCryptoModal(false);
    setCurrentOrder(null);
    setConfirmedOrder(paidOrder);
    fetchProducts(); // Refresh download counts
  };

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col text-zinc-900">
      
      {/* Top Navigation Bar */}
      <Header
        currency={currency}
        onCurrencyChange={setCurrency}
        onOpenTracker={() => setShowTrackerModal(true)}
        onOpenSupport={() => {
          setSupportInitialOrderId('');
          setShowSupportModal(true)}
        }
        onOpenAdmin={() => setShowAdminModal(true)}
        onFilterCategory={(cat) => {
          setSelectedCategory(cat);
          setSearchQuery('');
        }}
      />

      {/* Hero with Search and Filters */}
      <Hero
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        categories={CATEGORIES}
      />

      {/* Main Catalog Section */}
      <main id="catalog-section" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900">
              {selectedCategory === 'All' ? 'Featured Digital Catalog' : selectedCategory}
            </h2>
            <p className="text-xs text-zinc-500 mt-1">
              Showing {filteredProducts.length} verified digital items · Instant automated access upon payment
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSetupGuideModal(true)}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-zinc-700 bg-white hover:bg-zinc-100 border border-zinc-200 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5 text-zinc-600" />
              <span>Gateway Setup Guide</span>
            </button>
          </div>
        </div>

        {isLoading ? (
          <div className="py-24 flex flex-col items-center justify-center text-zinc-400">
            <RefreshCw className="w-8 h-8 animate-spin mb-3" />
            <span className="text-xs font-medium">Loading digital store catalog...</span>
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                currency={currency}
                onSelect={(p) => setActiveProduct(p)}
                onInstantBuy={(p) => setCheckoutProduct(p)}
              />
            ))}
          </div>
        ) : (
          <div className="py-16 text-center bg-white rounded-2xl border border-zinc-200 p-8 shadow-xs">
            <FileText className="w-12 h-12 stroke-1 text-zinc-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-zinc-900">No matching products found</h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
              We couldn&apos;t find any digital downloads matching &quot;{searchQuery}&quot;. Try adjusting your keywords or browse all categories.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="mt-4 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Story / Craftsmanship Section */}
        <section className="mt-20 pt-12 border-t border-zinc-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-900 mb-3">
                <ShieldCheck className="w-5 h-5 stroke-1.5" />
              </div>
              <h4 className="text-sm font-bold text-zinc-900">Private Isolated Storage</h4>
              <p className="text-xs text-zinc-500 leading-relaxed">
                PDFs are never stored in public directories. Download links use dynamic HMAC tokens that expire automatically to prevent unauthorized redistribution.
              </p>
            </div>

            <div className="space-y-2">
              <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-900 mb-3">
                <Smartphone className="w-5 h-5 stroke-1.5" />
              </div>
              <h4 className="text-sm font-bold text-zinc-900">JazzCash Verified Gateway</h4>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Customers in Pakistan can pay effortlessly with JazzCash Mobile Wallets or Cards. Payments are verified server-side with zero reliance on manual screenshots.
              </p>
            </div>

            <div className="space-y-2">
              <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-900 mb-3">
                <Globe className="w-5 h-5 stroke-1.5" />
              </div>
              <h4 className="text-sm font-bold text-zinc-900">Global Cryptocurrency Invoices</h4>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Worldwide customers can pay using USDT (TRC-20), Bitcoin, Ethereum, and Solana. Blockchain confirmations trigger automated token delivery in real time.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-zinc-200 bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-zinc-900 rounded-xs"></span>
                <span className="font-bold text-sm tracking-tight text-zinc-900">OmniStore Digital</span>
              </div>
              <p className="text-xs text-zinc-500 mt-1">
                Professional digital publishing & automated electronic file distribution.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-xs text-zinc-500 font-medium">
              <button
                onClick={() => setShowTrackerModal(true)}
                className="hover:text-zinc-900 transition-colors cursor-pointer"
              >
                Track Existing Order
              </button>
              <button
                onClick={() => {
                  setSupportInitialOrderId('');
                  setShowSupportModal(true);
                }}
                className="hover:text-zinc-900 transition-colors cursor-pointer"
              >
                Customer Support & Refunds
              </button>
              <button
                onClick={() => setShowSetupGuideModal(true)}
                className="hover:text-zinc-900 transition-colors cursor-pointer"
              >
                Gateway Setup Guide
              </button>
              <button
                onClick={() => setShowAdminModal(true)}
                className="hover:text-zinc-900 transition-colors cursor-pointer text-zinc-800 font-semibold"
              >
                Admin Control Center
              </button>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-400">
            <span>&copy; {new Date().getFullYear()} OmniStore Digital. All rights reserved.</span>
            <div className="flex items-center gap-4">
              <span>Dual Currency: PKR &middot; USD</span>
              <span>256-Bit SSL Encryption</span>
            </div>
          </div>
        </div>
      </footer>

      {/* MODALS */}

      {/* Product Detail Modal */}
      {activeProduct && (
        <ProductDetailModal
          product={activeProduct}
          currency={currency}
          onClose={() => setActiveProduct(null)}
          onBuyNow={(p) => {
            setActiveProduct(null);
            setCheckoutProduct(p);
          }}
        />
      )}

      {/* Checkout Modal */}
      {checkoutProduct && (
        <CheckoutModal
          product={checkoutProduct}
          currency={currency}
          onCurrencyChange={setCurrency}
          onClose={() => setCheckoutProduct(null)}
          onOrderCreated={handleOrderCreated}
        />
      )}

      {/* JazzCash Payment Modal */}
      {showJazzCashModal && currentOrder && (
        <JazzCashPaymentModal
          order={currentOrder}
          onClose={() => setShowJazzCashModal(false)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Crypto Payment Modal */}
      {showCryptoModal && currentOrder && (
        <CryptoPaymentModal
          order={currentOrder}
          onClose={() => setShowCryptoModal(false)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Order Confirmation & Immediate Download Modal */}
      {confirmedOrder && (
        <OrderConfirmationModal
          order={confirmedOrder}
          onClose={() => setConfirmedOrder(null)}
          onOpenSupport={() => {
            setSupportInitialOrderId(confirmedOrder.id);
            setConfirmedOrder(null);
            setShowSupportModal(true);
          }}
        />
      )}

      {/* Order Tracker Modal */}
      {showTrackerModal && (
        <OrderTrackerModal
          onClose={() => setShowTrackerModal(false)}
          onSelectOrder={(order) => {
            setShowTrackerModal(false);
            if (order.paymentStatus === 'paid') {
              setConfirmedOrder(order);
            } else if (order.paymentMethod === 'jazzcash') {
              setCurrentOrder(order);
              setShowJazzCashModal(true);
            } else {
              setCurrentOrder(order);
              setShowCryptoModal(true);
            }
          }}
          onOpenSupport={(orderId) => {
            setShowTrackerModal(false);
            setSupportInitialOrderId(orderId || '');
            setShowSupportModal(true);
          }}
        />
      )}

      {/* Support & Refund Modal */}
      {showSupportModal && (
        <SupportModal
          initialOrderId={supportInitialOrderId}
          onClose={() => setShowSupportModal(false)}
        />
      )}

      {/* Setup Guide Modal */}
      {showSetupGuideModal && (
        <SetupGuideModal onClose={() => setShowSetupGuideModal(false)} />
      )}

      {/* Admin Dashboard */}
      {showAdminModal && (
        <AdminDashboard
          onClose={() => setShowAdminModal(false)}
          onOpenSetupGuide={() => {
            setShowAdminModal(false);
            setShowSetupGuideModal(true);
          }}
        />
      )}

    </div>
  );
}
