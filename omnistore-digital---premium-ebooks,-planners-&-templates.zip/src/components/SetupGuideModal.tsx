import React from 'react';
import { X, ExternalLink, ShieldCheck, Key, BookOpen, CheckCircle2, Server, Smartphone, Globe } from 'lucide-react';

interface SetupGuideModalProps {
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-500 mb-1">
            <BookOpen className="w-4 h-4 text-zinc-700" />
            <span>Complete Setup & Deployment Guide</span>
          </div>
          <h2 className="text-2xl font-extrabold text-zinc-900 tracking-tight">
            Connecting Payment Gateways & Live Production Setup
          </h2>
          <p className="text-xs text-zinc-500 mt-1">
            Follow this step-by-step checklist to connect your official JazzCash merchant account and cryptocurrency payment gateway.
          </p>
        </div>

        <div className="space-y-8 text-xs text-zinc-700">
          
          {/* Section 1: JazzCash */}
          <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-3">
            <div className="flex items-center gap-2 text-red-700 font-bold text-sm">
              <Smartphone className="w-4 h-4" />
              <span>1. Official JazzCash Merchant Account Integration</span>
            </div>
            
            <p className="leading-relaxed">
              JazzCash requires an active <strong>Corporate or Merchant Account</strong> issued by Mobilink Microfinance Bank.
            </p>

            <ol className="list-decimal list-inside space-y-2 text-[11px] leading-relaxed">
              <li>
                <strong>Register on JazzCash Merchant Portal:</strong> Visit <span className="font-mono text-zinc-900">sandbox.jazzcash.com.pk</span> for testing or <span className="font-mono text-zinc-900">payments.jazzcash.com.pk</span> for production.
              </li>
              <li>
                <strong>Obtain Credentials:</strong> In the JazzCash Merchant portal, navigate to <em>Merchant Tools &rarr; API Credentials</em>. Note down your:
                <ul className="list-disc list-inside pl-4 mt-1 font-mono text-zinc-900 space-y-0.5">
                  <li>Merchant ID (e.g. MC12345)</li>
                  <li>Password</li>
                  <li>Integrity Salt (used for HMAC-SHA256 checksum generation)</li>
                </ul>
              </li>
              <li>
                <strong>Configure Return URL & IPN:</strong> Under <em>Return URL Configuration</em>, configure your store callback URL:
                <div className="mt-1 font-mono bg-zinc-900 text-zinc-100 p-2 rounded text-[10px]">
                  https://your-domain.com/api/payments/jazzcash/callback
                </div>
              </li>
              <li>
                <strong>Switch Environment in Admin:</strong> Open the <em>Gateways</em> tab in the Admin Dashboard, paste your credentials, toggle from <strong>Sandbox</strong> to <strong>Live</strong>, and click Save.
              </li>
            </ol>
          </div>

          {/* Section 2: Cryptocurrency */}
          <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-3">
            <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
              <Globe className="w-4 h-4" />
              <span>2. Cryptocurrency Gateway Setup (NOWPayments / BTCPay)</span>
            </div>
            
            <p className="leading-relaxed">
              Accept USDT (TRC-20), Bitcoin, Ethereum, and Solana with zero chargeback risks and low settlement fees.
            </p>

            <ol className="list-decimal list-inside space-y-2 text-[11px] leading-relaxed">
              <li>
                <strong>Sign up on NOWPayments or BTCPay Server:</strong> Visit <span className="font-mono text-zinc-900">nowpayments.io</span> and create a free merchant account.
              </li>
              <li>
                <strong>Add Your Payout Wallets:</strong> Enter your personal or business wallet addresses for USDT (Tron TRC-20), Bitcoin (SegWit), Ethereum, and Solana.
              </li>
              <li>
                <strong>Generate API Key & IPN Secret:</strong> Go to <em>Store Settings &rarr; Instant Payment Notifications (IPN)</em>. Copy your API Key and IPN Secret.
              </li>
              <li>
                <strong>Configure Webhook URL:</strong> Set your webhook notification target to:
                <div className="mt-1 font-mono bg-zinc-900 text-zinc-100 p-2 rounded text-[10px]">
                  https://your-domain.com/api/payments/crypto/webhook
                </div>
              </li>
              <li>
                <strong>Update Admin Settings:</strong> Save your wallets and keys in the Admin Settings tab.
              </li>
            </ol>
          </div>

          {/* Section 3: Automatic PDF Delivery & Private Storage */}
          <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-3">
            <div className="flex items-center gap-2 text-zinc-900 font-bold text-sm">
              <ShieldCheck className="w-4 h-4" />
              <span>3. Private PDF Storage Security Architecture</span>
            </div>

            <p className="leading-relaxed">
              This store uses <strong>Isolated Private Storage</strong>. PDF files are saved in <span className="font-mono text-zinc-800">./storage/digital_files/</span> and are completely inaccessible via standard web URLs.
            </p>

            <ul className="list-disc list-inside space-y-1 text-[11px] leading-relaxed">
              <li>Digital files can only be accessed via HMAC-signed, expiring download tokens (<span className="font-mono">/api/downloads/:token</span>).</li>
              <li>The server verifies that the order status is strictly <span className="font-mono font-bold text-emerald-700">paid</span> before streaming.</li>
              <li>Configurable download limits (default 5 downloads) prevent link sharing and piracy.</li>
              <li>Expired links return a clean HTTP 403 with support request options.</li>
            </ul>
          </div>

          {/* Section 4: Production Deployment Checklist */}
          <div className="p-5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-3">
            <div className="flex items-center gap-2 text-blue-700 font-bold text-sm">
              <Server className="w-4 h-4" />
              <span>4. Production Deployment Checklist</span>
            </div>

            <div className="space-y-1.5 text-[11px] leading-relaxed">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Build optimized bundle: <code className="font-mono bg-zinc-200 px-1 py-0.5 rounded">npm run build</code></span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Run full-stack server on port 3000: <code className="font-mono bg-zinc-200 px-1 py-0.5 rounded">npm run start</code></span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Set your custom production domain in <code className="font-mono bg-zinc-200 px-1 py-0.5 rounded">APP_URL</code> environment variable</span>
              </div>
            </div>
          </div>

        </div>

        <div className="mt-8 pt-4 border-t border-zinc-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-zinc-900 text-white rounded-xl text-xs font-semibold hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            I Understand, Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
