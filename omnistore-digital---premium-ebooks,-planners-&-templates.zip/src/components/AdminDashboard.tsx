import React, { useState, useEffect } from 'react';
import {
  Product,
  Order,
  SupportTicket,
  StoreSettings,
  EmailLog,
  SalesReport,
  ProductCategory
} from '../types.js';
import { formatPrice } from '../utils/currency.js';
import {
  X,
  Plus,
  Upload,
  Trash2,
  Edit,
  CheckCircle2,
  RefreshCw,
  DollarSign,
  TrendingUp,
  Download,
  ShieldCheck,
  Smartphone,
  Globe,
  Mail,
  HelpCircle,
  Eye,
  Lock,
  Save,
  Check,
  Search,
  BookOpen
} from 'lucide-react';

interface AdminDashboardProps {
  onClose: () => void;
  onOpenSetupGuide: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onClose,
  onOpenSetupGuide
}) => {
  // Password requirement removed: admin token is active by default
  const token = 'omni_admin_session_key_2026';
  const [activeTab, setActiveTab] = useState<
    'analytics' | 'products' | 'orders' | 'support' | 'gateways' | 'emails'
  >('analytics');

  // Data states
  const [analytics, setAnalytics] = useState<SalesReport | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [emails, setEmails] = useState<EmailLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState('');

  // Modals inside Admin
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [previewEmail, setPreviewEmail] = useState<EmailLog | null>(null);
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState<string>('');

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3500);
  };

  // Fetch all admin data
  const fetchData = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      const [resAnalytics, resProducts, resOrders, resTickets, resSettings, resEmails] =
        await Promise.all([
          fetch('/api/admin/analytics', { headers }),
          fetch('/api/admin/products', { headers }),
          fetch('/api/admin/orders', { headers }),
          fetch('/api/admin/tickets', { headers }),
          fetch('/api/admin/settings', { headers }),
          fetch('/api/admin/emails', { headers })
        ]);

      if (resAnalytics.ok) setAnalytics((await resAnalytics.json()).report);
      if (resProducts.ok) setProducts((await resProducts.json()).products);
      if (resOrders.ok) setOrders((await resOrders.json()).orders);
      if (resTickets.ok) setTickets((await resTickets.json()).tickets);
      if (resSettings.ok) setSettings((await resSettings.json()).settings);
      if (resEmails.ok) setEmails((await resEmails.json()).emails);
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchData();
    }
  }, [token]);

  // Product CRUD
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.title || !editingProduct?.priceUSD || !editingProduct?.pricePKR) {
      alert('Please fill in Title, USD Price, and PKR Price');
      return;
    }

    try {
      const res = await fetch('/api/admin/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(editingProduct)
      });
      const data = await res.json();
      if (res.ok) {
        showNotification('Product saved successfully');
        setEditingProduct(null);
        fetchData();
      } else {
        alert(data.error || 'Failed to save product');
      }
    } catch (err) {
      console.error(err);
      alert('Error saving product');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        showNotification('Product deleted');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Upload digital file into private storage
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const res = await fetch('/api/admin/upload-file', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            fileName: file.name,
            base64Content: base64
          })
        });
        const data = await res.json();
        if (res.ok) {
          setEditingProduct((prev) => ({
            ...prev,
            fileName: data.fileName,
            fileSize: data.fileSize,
            fileFormat: data.fileFormat
          }));
          showNotification(`File uploaded to private storage: ${data.fileName}`);
        } else {
          alert(data.error || 'Upload failed');
        }
      } catch (err) {
        console.error(err);
        alert('File upload error');
      }
    };
    reader.readAsDataURL(file);
  };

  // Upload cover image
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const res = await fetch('/api/admin/upload-cover', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            fileName: file.name,
            base64Content: base64
          })
        });
        const data = await res.json();
        if (res.ok) {
          setEditingProduct((prev) => ({
            ...prev,
            coverImage: data.url
          }));
          showNotification('Cover image uploaded');
        }
      } catch (err) {
        console.error(err);
      }
    };
    reader.readAsDataURL(file);
  };

  // Order Actions
  const handleVerifyPaid = async (orderId: string) => {
    if (!confirm('Mark this order as verified and paid? Customer will receive their download link.')) return;
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/verify-paid`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        showNotification('Order marked as paid and fulfillment issued.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRefundOrder = async (orderId: string) => {
    const reason = prompt('Reason for refund:');
    if (!reason) return;
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/refund`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ reason })
      });
      if (res.ok) {
        showNotification('Order refunded.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReissueToken = async (orderId: string) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/reissue-token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ extensionHours: 72, resetCount: true })
      });
      if (res.ok) {
        showNotification('Download link re-issued & extended for 72 hours.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        showNotification('Gateway & store settings saved.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Resend email
  const handleResendEmail = async (emailId: string) => {
    try {
      const res = await fetch(`/api/admin/emails/resend/${emailId}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        showNotification('Order confirmation email resent.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };



  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    if (orderFilter !== 'all' && o.paymentStatus !== orderFilter) return false;
    if (orderSearch) {
      const q = orderSearch.toLowerCase();
      return (
        o.id.toLowerCase().includes(q) ||
        o.customerEmail.toLowerCase().includes(q) ||
        o.productTitle.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 overflow-y-auto bg-zinc-900/80 backdrop-blur-xs">
      <div className="relative bg-white rounded-2xl w-full max-w-6xl max-h-[96vh] flex flex-col border border-zinc-200 shadow-2xl overflow-hidden">
        
        {/* Top Bar */}
        <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-3">
            <span className="font-black text-sm tracking-tight text-zinc-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-zinc-900 rounded-xs"></span>
              OmniStore Admin Portal
            </span>
            <span className="text-zinc-300">|</span>
            <span className="text-xs text-zinc-500 font-mono">Role: Super Admin</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onOpenSetupGuide}
              className="px-3 py-1.5 bg-white border border-zinc-200 hover:border-zinc-300 text-zinc-700 hover:text-zinc-900 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Setup Guide</span>
            </button>
            <button
              type="button"
              onClick={fetchData}
              className="p-2 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-zinc-800 rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Notification Banner */}
        {notification && (
          <div className="bg-emerald-600 text-white px-6 py-2 text-xs font-medium flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>{notification}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex border-b border-zinc-200 px-6 gap-6 text-xs font-semibold overflow-x-auto scrollbar-none bg-white shrink-0">
          {[
            { id: 'analytics', label: 'Overview & Revenue', icon: TrendingUp },
            { id: 'products', label: `Products (${products.length})`, icon: DollarSign },
            { id: 'orders', label: `Orders (${orders.length})`, icon: Download },
            { id: 'support', label: `Support & Refunds (${tickets.length})`, icon: HelpCircle },
            { id: 'gateways', label: 'Payment Gateways & Settings', icon: Globe },
            { id: 'emails', label: `Email Outbox (${emails.length})`, icon: Mail }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'border-zinc-900 text-zinc-900'
                    : 'border-transparent text-zinc-500 hover:text-zinc-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-zinc-50/50">
          
          {/* TAB 1: Analytics & Revenue */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              {analytics ? (
                <>
                  {/* Top Metric Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-xs">
                      <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
                        Total Revenue (USD)
                      </span>
                      <span className="text-2xl font-black text-zinc-900 tabular-nums">
                        ${analytics.totalRevenueUSD.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-zinc-500 mt-1 block">
                        ≈ Rs {analytics.totalRevenuePKR.toLocaleString()} PKR
                      </span>
                    </div>

                    <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-xs">
                      <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
                        Verified Paid Orders
                      </span>
                      <span className="text-2xl font-black text-zinc-900 tabular-nums">
                        {analytics.totalPaidOrders}
                      </span>
                      <span className="text-[11px] text-emerald-600 mt-1 block font-medium">
                        Conversion: {analytics.conversionRate}%
                      </span>
                    </div>

                    <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-xs">
                      <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
                        JazzCash Revenue (PKR)
                      </span>
                      <span className="text-2xl font-black text-zinc-900 tabular-nums">
                        Rs {analytics.jazzcashRevenuePKR.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-zinc-500 mt-1 block">
                        Mobile Wallets & Cards
                      </span>
                    </div>

                    <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-xs">
                      <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
                        Crypto Revenue (USD)
                      </span>
                      <span className="text-2xl font-black text-zinc-900 tabular-nums">
                        ${analytics.cryptoRevenueUSD.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-zinc-500 mt-1 block">
                        USDT, BTC, ETH & SOL
                      </span>
                    </div>
                  </div>

                  {/* Top Selling Products */}
                  <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs">
                    <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider mb-3">
                      Best Selling Digital Products
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-zinc-100 text-zinc-400">
                            <th className="py-2">Product Title</th>
                            <th className="py-2 text-right">Units Sold</th>
                            <th className="py-2 text-right">Estimated Revenue (USD)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-100 text-zinc-700">
                          {analytics.topProducts.map((p) => (
                            <tr key={p.id}>
                              <td className="py-2.5 font-medium text-zinc-900">{p.title}</td>
                              <td className="py-2.5 text-right font-mono">{p.count}</td>
                              <td className="py-2.5 text-right font-mono font-semibold text-zinc-900">
                                ${p.revenueUSD}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Recent 7-Day Sales Activity */}
                  <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs">
                    <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider mb-3">
                      Recent 7-Day Performance
                    </h4>
                    <div className="grid grid-cols-7 gap-2">
                      {analytics.recentSales.map((day) => (
                        <div
                          key={day.date}
                          className="p-3 rounded-lg bg-zinc-50 border border-zinc-200 text-center"
                        >
                          <span className="text-[10px] text-zinc-400 block font-mono">
                            {day.date.slice(5)}
                          </span>
                          <span className="text-xs font-bold text-zinc-900 block mt-1 tabular-nums">
                            ${day.amountUSD}
                          </span>
                          <span className="text-[10px] text-zinc-500 block">
                            {day.count} orders
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-8 text-center text-zinc-400 text-xs">Loading sales reports...</div>
              )}
            </div>
          )}

          {/* TAB 2: Products Management */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-zinc-900">Digital Product Catalog</h3>
                  <p className="text-xs text-zinc-500">
                    Upload cover images, digital PDF files into private storage, set dual pricing, and publish items.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setEditingProduct({
                      title: '',
                      tagline: '',
                      description: '',
                      category: 'eBooks & Handbooks',
                      priceUSD: 19,
                      pricePKR: 5200,
                      isPublished: true,
                      whatsIncluded: ['Full Digital PDF Download'],
                      features: ['Instant Download', 'Lifetime Access']
                    })
                  }
                  className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              </div>

              {/* Products Table */}
              <div className="bg-white rounded-xl border border-zinc-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500">
                    <tr>
                      <th className="py-3 px-4">Cover</th>
                      <th className="py-3 px-4">Title & Category</th>
                      <th className="py-3 px-4">File In Private Storage</th>
                      <th className="py-3 px-4">Price (USD / PKR)</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Downloads</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 text-zinc-700">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-zinc-50/50">
                        <td className="py-2.5 px-4">
                          <div className="w-10 h-10 rounded-md bg-zinc-100 overflow-hidden border border-zinc-200">
                            <img src={p.coverImage} alt={p.title} className="w-full h-full object-cover" />
                          </div>
                        </td>
                        <td className="py-2.5 px-4">
                          <span className="font-semibold text-zinc-900 block">{p.title}</span>
                          <span className="text-[11px] text-zinc-400">{p.category}</span>
                        </td>
                        <td className="py-2.5 px-4">
                          <span className="font-mono text-[11px] text-zinc-800 block truncate max-w-xs">
                            {p.fileName}
                          </span>
                          <span className="text-[10px] text-zinc-400">
                            {p.fileSize} · {p.fileFormat}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-mono">
                          <span className="text-zinc-900 font-bold">${p.priceUSD}</span>
                          <span className="text-zinc-400 block text-[11px]">Rs {p.pricePKR.toLocaleString()}</span>
                        </td>
                        <td className="py-2.5 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              p.isPublished
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-zinc-100 text-zinc-600'
                            }`}
                          >
                            {p.isPublished ? 'Published' : 'Draft'}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-mono">{p.downloadsCount}</td>
                        <td className="py-2.5 px-4 text-right space-x-2">
                          <button
                            type="button"
                            onClick={() => setEditingProduct(p)}
                            className="p-1 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 rounded cursor-pointer"
                            title="Edit Product"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer"
                            title="Delete Product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Orders & Transactions */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-zinc-900">Orders & Payment Tracking</h3>
                  <p className="text-xs text-zinc-500">
                    Live payments, transaction hashes, download limits, and manual verification override.
                  </p>
                </div>

                {/* Filter and Search */}
                <div className="flex items-center gap-2">
                  <select
                    value={orderFilter}
                    onChange={(e) => setOrderFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs bg-white border border-zinc-200 rounded-lg text-zinc-700"
                  >
                    <option value="all">All Statuses</option>
                    <option value="paid">Paid Only</option>
                    <option value="pending">Pending</option>
                    <option value="refunded">Refunded</option>
                    <option value="failed">Failed</option>
                  </select>

                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="Search order or email..."
                    className="px-3 py-1.5 text-xs bg-white border border-zinc-200 rounded-lg text-zinc-700"
                  />
                </div>
              </div>

              {/* Orders Table */}
              <div className="bg-white rounded-xl border border-zinc-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500">
                    <tr>
                      <th className="py-3 px-4">Order ID & Date</th>
                      <th className="py-3 px-4">Customer Email</th>
                      <th className="py-3 px-4">Product</th>
                      <th className="py-3 px-4">Gateway & Ref</th>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Downloads</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 text-zinc-700">
                    {filteredOrders.map((o) => (
                      <tr key={o.id} className="hover:bg-zinc-50/50">
                        <td className="py-2.5 px-4">
                          <span className="font-mono font-bold text-zinc-900 block">{o.id}</span>
                          <span className="text-[10px] text-zinc-400">
                            {new Date(o.createdAt).toLocaleDateString()}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-medium">{o.customerEmail}</td>
                        <td className="py-2.5 px-4 truncate max-w-xs">{o.productTitle}</td>
                        <td className="py-2.5 px-4">
                          <span className="font-semibold text-zinc-900 uppercase block">
                            {o.paymentMethod}
                          </span>
                          <span className="font-mono text-[10px] text-zinc-400 truncate max-w-36 block">
                            {o.paymentGatewayRef || 'Awaiting txn'}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-mono font-bold text-zinc-900">
                          {formatPrice(o.amount, o.currency)}
                        </td>
                        <td className="py-2.5 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              o.paymentStatus === 'paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : o.paymentStatus === 'pending'
                                ? 'bg-amber-100 text-amber-800'
                                : o.paymentStatus === 'refunded'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {o.paymentStatus}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 font-mono">
                          {o.downloadCount} / {o.maxDownloads}
                        </td>
                        <td className="py-2.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                          {o.paymentStatus !== 'paid' && (
                            <button
                              type="button"
                              onClick={() => handleVerifyPaid(o.id)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold cursor-pointer"
                              title="Manual Payment Verification"
                            >
                              Verify Paid
                            </button>
                          )}
                          {o.paymentStatus === 'paid' && (
                            <button
                              type="button"
                              onClick={() => handleReissueToken(o.id)}
                              className="px-2 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded text-[11px] font-medium cursor-pointer"
                              title="Reset link count and extend 72 hours"
                            >
                              Extend Link
                            </button>
                          )}
                          {o.paymentStatus === 'paid' && (
                            <button
                              type="button"
                              onClick={() => handleRefundOrder(o.id)}
                              className="px-2 py-1 bg-red-100 hover:bg-red-200 text-red-700 rounded text-[11px] font-medium cursor-pointer"
                            >
                              Refund
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: Support & Refunds */}
          {activeTab === 'support' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Customer Support & Refund Inquiries</h3>
                <p className="text-xs text-zinc-500">
                  Manage incoming customer assistance tickets and refund authorizations.
                </p>
              </div>

              <div className="space-y-3">
                {tickets.map((t) => (
                  <div key={t.id} className="p-4 bg-white rounded-xl border border-zinc-200 shadow-xs space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-xs text-zinc-900">{t.id}</span>
                          <span className="text-[10px] font-mono text-zinc-500">Order: {t.orderId}</span>
                          <span
                            className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              t.status === 'resolved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {t.status}
                          </span>
                        </div>
                        <h5 className="text-sm font-semibold text-zinc-900 mt-1">{t.subject}</h5>
                        <p className="text-xs text-zinc-500">From: {t.customerEmail}</p>
                      </div>

                      <div className="text-xs text-zinc-400">
                        {new Date(t.createdAt).toLocaleString()}
                      </div>
                    </div>

                    <p className="text-xs text-zinc-700 bg-zinc-50 p-3 rounded-lg border border-zinc-100">
                      &quot;{t.message}&quot;
                    </p>

                    <div className="pt-2 flex items-center justify-between text-xs">
                      <span className="text-zinc-500 text-[11px]">
                        {t.adminNotes ? `Admin Note: ${t.adminNotes}` : 'No notes recorded'}
                      </span>

                      {t.status === 'open' && (
                        <div className="space-x-2">
                          <button
                            type="button"
                            onClick={async () => {
                              const note = prompt('Enter resolution note:');
                              await fetch(`/api/admin/tickets/${t.id}`, {
                                method: 'POST',
                                headers: {
                                  'Content-Type': 'application/json',
                                  Authorization: `Bearer ${token}`
                                },
                                body: JSON.stringify({ status: 'resolved', adminNotes: note || 'Resolved' })
                              });
                              showNotification('Ticket marked as resolved');
                              fetchData();
                            }}
                            className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white rounded text-xs font-semibold cursor-pointer"
                          >
                            Mark Resolved
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: Payment Gateways & Store Settings */}
          {activeTab === 'gateways' && settings && (
            <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-zinc-900">
                    Payment Gateway Numbers & Account Settings (پیمنٹ نمبرز اور اکاؤنٹ تفصیلات)
                  </h3>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Add or edit your JazzCash receiver number, EasyPaisa mobile account, account titles, and gateway credentials.
                  </p>
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save All Settings (محفوظ کریں)</span>
                </button>
              </div>

              {/* CARD 1: JazzCash & EasyPaisa Mobile Numbers & Titles (Primary) */}
              <div className="p-5 bg-white rounded-2xl border-2 border-red-500/20 shadow-xs space-y-5">
                <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center font-bold text-xs">
                      JC
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-zinc-900">
                        JazzCash & Mobile Account Numbers (جاز کیش اکاؤنٹ نمبرز)
                      </h4>
                      <p className="text-[11px] text-zinc-500">
                        This is the number customers see to pay via JazzCash or direct mobile transfer.
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-semibold text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-200">
                    Active on Storefront
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  {/* JazzCash Receiver Mobile Number */}
                  <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <label className="block text-zinc-900 font-bold mb-1">
                      JazzCash Mobile Number (جاز کیش موبائل نمبر) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.jazzcash.merchantMobileNumber || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, merchantMobileNumber: e.target.value }
                        })
                      }
                      placeholder="e.g. 03001234567"
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono font-semibold"
                    />
                    <span className="text-[11px] text-zinc-500 mt-1 block">
                      Customers will send money to or enter this JazzCash number during checkout.
                    </span>
                  </div>

                  {/* JazzCash Account Title */}
                  <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <label className="block text-zinc-900 font-bold mb-1">
                      Account Title / Name (اکاؤنٹ ہولڈر کا نام) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.jazzcash.accountTitle || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, accountTitle: e.target.value }
                        })
                      }
                      placeholder="e.g. Muhammad Asim Khan"
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-medium"
                    />
                    <span className="text-[11px] text-zinc-500 mt-1 block">
                      Beneficiary name shown to customer to confirm recipient identity.
                    </span>
                  </div>

                  {/* EasyPaisa Mobile Number */}
                  <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-zinc-900 font-bold">
                        EasyPaisa Mobile Number (ایزی پیسہ نمبر)
                      </label>
                      <label className="text-[11px] text-zinc-500 flex items-center gap-1 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.easypaisa?.enabled ?? true}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              easypaisa: {
                                ...(settings.easypaisa || { mobileNumber: '', accountTitle: '' }),
                                enabled: e.target.checked,
                                mobileNumber: settings.easypaisa?.mobileNumber || '',
                                accountTitle: settings.easypaisa?.accountTitle || ''
                              }
                            })
                          }
                          className="rounded text-zinc-900"
                        />
                        <span>Enable EasyPaisa</span>
                      </label>
                    </div>
                    <input
                      type="text"
                      value={settings.easypaisa?.mobileNumber || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          easypaisa: {
                            ...(settings.easypaisa || { enabled: true, accountTitle: '' }),
                            enabled: settings.easypaisa?.enabled ?? true,
                            accountTitle: settings.easypaisa?.accountTitle || '',
                            mobileNumber: e.target.value
                          }
                        })
                      }
                      placeholder="e.g. 03451234567"
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono font-semibold"
                    />
                    <span className="text-[11px] text-zinc-500 mt-1 block">
                      Optional secondary receiver number for EasyPaisa wallet payments.
                    </span>
                  </div>

                  {/* EasyPaisa Account Title */}
                  <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <label className="block text-zinc-900 font-bold mb-1">
                      EasyPaisa Account Title (ایزی پیسہ اکاؤنٹ ٹائٹل)
                    </label>
                    <input
                      type="text"
                      value={settings.easypaisa?.accountTitle || ''}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          easypaisa: {
                            ...(settings.easypaisa || { enabled: true, mobileNumber: '' }),
                            enabled: settings.easypaisa?.enabled ?? true,
                            mobileNumber: settings.easypaisa?.mobileNumber || '',
                            accountTitle: e.target.value
                          }
                        })
                      }
                      placeholder="e.g. Muhammad Asim Khan"
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-medium"
                    />
                    <span className="text-[11px] text-zinc-500 mt-1 block">
                      Title registered on your EasyPaisa account.
                    </span>
                  </div>
                </div>

                {/* Quick Save numbers button */}
                <div className="pt-2 flex items-center justify-between text-xs">
                  <span className="text-zinc-500">
                    Changes take effect immediately on checkout and payment screens.
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSaveSettings(e as any);
                    }}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Payment Numbers (نمبر محفوظ کریں)</span>
                  </button>
                </div>
              </div>

              {/* CARD 2: JazzCash Official Merchant API Credentials (Optional/Sandbox) */}
              <div className="p-5 bg-white rounded-xl border border-zinc-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-zinc-700" />
                    <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                      JazzCash Hosted Checkout Gateway API (Credentials)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-zinc-500">Gateway Mode:</span>
                    <select
                      value={settings.jazzcash.environment}
                      onChange={(e: any) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, environment: e.target.value }
                        })
                      }
                      className="text-xs font-semibold px-2 py-1 bg-zinc-100 border border-zinc-300 rounded"
                    >
                      <option value="sandbox">Sandbox (Testing / Manual)</option>
                      <option value="live">Live Merchant API</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Merchant ID</label>
                    <input
                      type="text"
                      value={settings.jazzcash.merchantId}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, merchantId: e.target.value }
                        })
                      }
                      placeholder="e.g. MC12345"
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Merchant Password</label>
                    <input
                      type="password"
                      value={settings.jazzcash.password}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, password: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Integrity Salt</label>
                    <input
                      type="password"
                      value={settings.jazzcash.integritySalt}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          jazzcash: { ...settings.jazzcash, integritySalt: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Crypto Section */}
              <div className="p-5 bg-white rounded-xl border border-zinc-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-emerald-600" />
                    <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                      Cryptocurrency Payment Gateway (NOWPayments / BTCPay)
                    </h4>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-zinc-500">Mode:</span>
                    <select
                      value={settings.crypto.environment}
                      onChange={(e: any) =>
                        setSettings({
                          ...settings,
                          crypto: { ...settings.crypto, environment: e.target.value }
                        })
                      }
                      className="text-xs font-semibold px-2 py-1 bg-zinc-100 border border-zinc-300 rounded"
                    >
                      <option value="sandbox">Sandbox Test</option>
                      <option value="live">Live On-Chain</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">USDT Wallet (TRON TRC-20)</label>
                    <input
                      type="text"
                      value={settings.crypto.usdtWallet}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          crypto: { ...settings.crypto, usdtWallet: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Bitcoin Wallet Address (BTC)</label>
                    <input
                      type="text"
                      value={settings.crypto.btcWallet}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          crypto: { ...settings.crypto, btcWallet: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Ethereum Wallet Address (ETH)</label>
                    <input
                      type="text"
                      value={settings.crypto.ethWallet}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          crypto: { ...settings.crypto, ethWallet: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Solana Wallet Address (SOL)</label>
                    <input
                      type="text"
                      value={settings.crypto.solWallet}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          crypto: { ...settings.crypto, solWallet: e.target.value }
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* General Store & Expiry Rules */}
              <div className="p-5 bg-white rounded-xl border border-zinc-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider border-b border-zinc-100 pb-3">
                  Store Rules & Automatic Delivery Expiry
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">USD to PKR Exchange Rate</label>
                    <input
                      type="number"
                      value={settings.usdToPkrRate}
                      onChange={(e) =>
                        setSettings({ ...settings, usdToPkrRate: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Link Expiration (Hours)</label>
                    <input
                      type="number"
                      value={settings.downloadLinkExpiryHours}
                      onChange={(e) =>
                        setSettings({ ...settings, downloadLinkExpiryHours: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-medium mb-1">Max Download Limit</label>
                    <input
                      type="number"
                      value={settings.maxDownloadLimit}
                      onChange={(e) =>
                        setSettings({ ...settings, maxDownloadLimit: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save All Settings</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 6: Email Outbox */}
          {activeTab === 'emails' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Automated Customer Email Outbox</h3>
                <p className="text-xs text-zinc-500">
                  Every order completion automatically creates and dispatches an HTML email containing the private download link and invoice.
                </p>
              </div>

              <div className="bg-white rounded-xl border border-zinc-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500">
                    <tr>
                      <th className="py-3 px-4">Recipient</th>
                      <th className="py-3 px-4">Subject</th>
                      <th className="py-3 px-4">Order ID</th>
                      <th className="py-3 px-4">Sent At</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 text-zinc-700">
                    {emails.map((e) => (
                      <tr key={e.id} className="hover:bg-zinc-50/50">
                        <td className="py-2.5 px-4 font-semibold text-zinc-900">{e.recipientEmail}</td>
                        <td className="py-2.5 px-4">{e.subject}</td>
                        <td className="py-2.5 px-4 font-mono">{e.orderId}</td>
                        <td className="py-2.5 px-4 text-zinc-400">
                          {new Date(e.sentAt).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-4">
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                            {e.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-4 text-right space-x-2">
                          <button
                            type="button"
                            onClick={() => setPreviewEmail(e)}
                            className="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded text-[11px] font-medium cursor-pointer"
                          >
                            Preview HTML
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResendEmail(e.id)}
                            className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-white rounded text-[11px] font-medium cursor-pointer"
                          >
                            Resend
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Modal: Add/Edit Product */}
        {editingProduct && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-zinc-900/70 backdrop-blur-xs overflow-y-auto">
            <div className="relative bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 border border-zinc-200 shadow-2xl">
              <button
                onClick={() => setEditingProduct(null)}
                className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-zinc-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-lg font-bold text-zinc-900 mb-4">
                {editingProduct.id ? 'Edit Digital Product' : 'Add New Digital Product'}
              </h3>

              <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                <div>
                  <label className="block text-zinc-700 font-semibold mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.title || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, title: e.target.value })
                    }
                    placeholder="e.g. Master Notion Freelance Suite"
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900"
                  />
                </div>

                <div>
                  <label className="block text-zinc-700 font-semibold mb-1">Tagline</label>
                  <input
                    type="text"
                    value={editingProduct.tagline || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, tagline: e.target.value })
                    }
                    placeholder="Short one-line subtitle"
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-zinc-700 font-semibold mb-1">Category</label>
                    <select
                      value={editingProduct.category || 'eBooks & Handbooks'}
                      onChange={(e: any) =>
                        setEditingProduct({ ...editingProduct, category: e.target.value })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900"
                    >
                      <option value="Planners & Journals">Planners & Journals</option>
                      <option value="eBooks & Handbooks">eBooks & Handbooks</option>
                      <option value="Productivity & Notion">Productivity & Notion</option>
                      <option value="Developer & Tech">Developer & Tech</option>
                      <option value="Templates & Bundles">Templates & Bundles</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-semibold mb-1">Pages / Slides Count</label>
                    <input
                      type="number"
                      value={editingProduct.pagesCount || 100}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          pagesCount: Number(e.target.value)
                        })
                      }
                      className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900"
                    />
                  </div>
                </div>

                {/* Dual Pricing */}
                <div className="grid grid-cols-2 gap-3 p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                  <div>
                    <label className="block text-zinc-700 font-semibold mb-1">Price in USD ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={editingProduct.priceUSD || ''}
                      onChange={(e) => {
                        const usd = Number(e.target.value);
                        setEditingProduct({
                          ...editingProduct,
                          priceUSD: usd,
                          pricePKR: Math.round(usd * (settings?.usdToPkrRate || 278))
                        });
                      }}
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-700 font-semibold mb-1">Price in PKR (Rs)</label>
                    <input
                      type="number"
                      required
                      value={editingProduct.pricePKR || ''}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          pricePKR: Number(e.target.value)
                        })
                      }
                      className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono"
                    />
                  </div>
                </div>

                {/* Upload Digital File Into Private Storage */}
                <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-zinc-900">Upload Digital PDF / Product File</span>
                    <span className="text-[10px] text-zinc-400">Stores in private /storage folder</span>
                  </div>
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    className="w-full text-xs text-zinc-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-zinc-900 file:text-white hover:file:bg-zinc-800"
                  />
                  {editingProduct.fileName && (
                    <div className="text-[11px] text-zinc-600 font-mono bg-white p-2 rounded border border-zinc-200">
                      Target: {editingProduct.fileName} ({editingProduct.fileSize} · {editingProduct.fileFormat})
                    </div>
                  )}
                </div>

                {/* Upload Cover Image */}
                <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                  <span className="font-semibold text-zinc-900 block">Cover Image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleCoverUpload}
                    className="w-full text-xs text-zinc-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-zinc-900 file:text-white hover:file:bg-zinc-800"
                  />
                  {editingProduct.coverImage && (
                    <div className="flex items-center gap-3 bg-white p-2 rounded border border-zinc-200">
                      <div className="w-10 h-10 rounded overflow-hidden bg-zinc-100">
                        <img src={editingProduct.coverImage} alt="Cover preview" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[11px] text-zinc-500 truncate max-w-xs">{editingProduct.coverImage}</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-zinc-700 font-semibold mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={editingProduct.description || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, description: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="pubSwitch"
                    checked={editingProduct.isPublished !== false}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, isPublished: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-zinc-900"
                  />
                  <label htmlFor="pubSwitch" className="text-zinc-800 font-semibold">
                    Published on Storefront
                  </label>
                </div>

                <div className="pt-3 border-t border-zinc-200 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingProduct(null)}
                    className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Save Digital Product
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Preview Dispatched HTML Email */}
        {previewEmail && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-zinc-900/70 backdrop-blur-xs">
            <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[85vh] overflow-y-auto p-6 border border-zinc-200 shadow-2xl">
              <button
                onClick={() => setPreviewEmail(null)}
                className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-zinc-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h4 className="text-sm font-bold text-zinc-900 mb-1">
                Rendered Customer Email Receipt
              </h4>
              <p className="text-xs text-zinc-500 mb-4">
                To: {previewEmail.recipientEmail} · Subject: {previewEmail.subject}
              </p>

              <div
                className="border border-zinc-200 rounded-xl p-4 bg-white"
                dangerouslySetInnerHTML={{ __html: previewEmail.htmlContent }}
              />

              <div className="mt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setPreviewEmail(null)}
                  className="px-4 py-2 bg-zinc-900 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
