import React, { useState } from 'react';
import { Order } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { X, Search, FileText, Download, Clock, ShieldCheck, AlertCircle, CheckCircle2 } from 'lucide-react';

interface OrderTrackerModalProps {
  onClose: () => void;
  onSelectOrder: (order: Order) => void;
  onOpenSupport: (orderId?: string) => void;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  onClose,
  onSelectOrder,
  onOpenSupport
}) => {
  const [query, setQuery] = useState('');
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsSearching(true);
    setErrorMsg('');
    try {
      const res = await fetch(`/api/orders/lookup/search?q=${encodeURIComponent(query.trim())}`);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to search orders');
      }
      setOrders(data.orders || []);
      setHasSearched(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error looking up orders');
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <h3 className="text-xl font-bold text-zinc-900 tracking-tight">
            Track Order & Access Downloads
          </h3>
          <p className="text-xs text-zinc-500 mt-1">
            Enter your Order ID (e.g. ORD-2026-78210) or your purchase email address to retrieve your order and download files.
          </p>
        </div>

        <form onSubmit={handleSearch} className="mb-6">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ORD-2026-XXXXX or your@email.com"
                className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-sm text-zinc-900 placeholder-zinc-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 disabled:bg-zinc-400 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              {isSearching ? 'Searching...' : 'Find Order'}
            </button>
          </div>
          {errorMsg && <p className="text-xs text-red-600 mt-2">{errorMsg}</p>}
        </form>

        {/* Results Area */}
        {hasSearched && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
              Search Results ({orders?.length || 0})
            </h4>

            {orders && orders.length > 0 ? (
              <div className="space-y-3">
                {orders.map((o) => (
                  <div
                    key={o.id}
                    className="p-4 rounded-xl border border-zinc-200 bg-zinc-50/70 hover:bg-white transition-all space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-zinc-900">{o.id}</span>
                          <span
                            className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              o.paymentStatus === 'paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : o.paymentStatus === 'pending'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {o.paymentStatus}
                          </span>
                        </div>
                        <h5 className="text-sm font-semibold text-zinc-900 mt-1">{o.productTitle}</h5>
                        <p className="text-xs text-zinc-500">
                          {formatPrice(o.amount, o.currency)} · via {o.paymentMethod.toUpperCase()}
                        </p>
                      </div>

                      {o.paymentStatus === 'paid' ? (
                        <a
                          href={`/api/downloads/${o.downloadToken}`}
                          className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download</span>
                        </a>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onSelectOrder(o)}
                          className="px-3 py-1.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-900 rounded-lg text-xs font-medium shrink-0 transition-colors cursor-pointer"
                        >
                          Complete Payment
                        </button>
                      )}
                    </div>

                    <div className="pt-2 border-t border-zinc-200/70 flex items-center justify-between text-[11px] text-zinc-500">
                      <span>Ordered {new Date(o.createdAt).toLocaleDateString()}</span>
                      <button
                        type="button"
                        onClick={() => onOpenSupport(o.id)}
                        className="text-zinc-600 hover:text-zinc-900 underline cursor-pointer"
                      >
                        Order issues / Support
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-zinc-50 rounded-xl border border-zinc-200 text-xs text-zinc-500">
                No orders found matching &quot;{query}&quot;. Please verify the email address or order reference used during checkout.
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
