import React, { useState, useEffect } from 'react';
import { Order } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { X, ShieldCheck, CheckCircle2, AlertCircle, ArrowRight, Smartphone, CreditCard, ExternalLink, RefreshCw } from 'lucide-react';

interface JazzCashPaymentModalProps {
  order: Order;
  onClose: () => void;
  onPaymentSuccess: (paidOrder: Order) => void;
}

export const JazzCashPaymentModal: React.FC<JazzCashPaymentModalProps> = ({
  order,
  onClose,
  onPaymentSuccess
}) => {
  const [paymentMode, setPaymentMode] = useState<'MWALLET' | 'CARD'>('MWALLET');
  const [mobileNumber, setMobileNumber] = useState(order.customerPhone || '03001234567');
  const [pin, setPin] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [gatewayPayload, setGatewayPayload] = useState<any>(null);
  const [isSandbox, setIsSandbox] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeTab, setActiveTab] = useState<'interactive' | 'official_form'>('interactive');

  // Load official gateway parameters from server
  useEffect(() => {
    async function initJazzCash() {
      try {
        const res = await fetch('/api/payments/jazzcash/initiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId: order.id,
            paymentMode,
            mobileNumber
          })
        });
        const data = await res.json();
        if (res.ok) {
          setGatewayPayload(data);
          setIsSandbox(data.isSandbox);
        }
      } catch (err) {
        console.error('Failed to initialize JazzCash params:', err);
      }
    }
    initJazzCash();
  }, [order.id, paymentMode]);

  // Handle Simulated / Test Verification
  const handleSimulatePayment = async () => {
    setIsProcessing(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/payments/jazzcash/simulate-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.id,
          mobileNumber,
          pin: pin || '1234'
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'JazzCash verification failed');
      }

      onPaymentSuccess(data.order);
    } catch (err: any) {
      setErrorMsg(err.message || 'Payment simulation failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[95vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* JazzCash Official Brand Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white font-black text-lg shadow-xs">
              JC
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-900 leading-tight">
                JazzCash Official Payment Gateway
              </h3>
              <p className="text-xs text-zinc-500">
                Order Reference: <span className="font-mono text-zinc-700">{order.id}</span>
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-zinc-400 block font-medium">Payable Amount</span>
            <span className="text-base font-bold text-zinc-900 tabular-nums">
              {formatPrice(order.amount, 'PKR')}
            </span>
          </div>
        </div>

        {/* Mode Notice Pill (Sandbox vs Live) */}
        <div className={`p-3 rounded-lg text-xs mb-5 flex items-start gap-2.5 ${
          isSandbox
            ? 'bg-amber-50 border border-amber-200 text-amber-900'
            : 'bg-emerald-50 border border-emerald-200 text-emerald-900'
        }`}>
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
          <div className="text-xs leading-relaxed">
            {isSandbox ? (
              <>
                <strong>Sandbox Test Mode Active:</strong> Live JazzCash merchant credentials can be added anytime in the Admin Dashboard. You can simulate instant payment verification right now to test automatic PDF delivery.
              </>
            ) : (
              <>
                <strong>Live Production Gateway:</strong> Connected to official Mobilink Microfinance Bank hosted checkout portal.
              </>
            )}
          </div>
        </div>

        {/* Merchant Receiving Number Display Card (Prominent) */}
        {gatewayPayload && (
          <div className="mb-5 p-4 bg-red-50/70 border border-red-200 rounded-2xl text-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-red-950 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-red-600" />
                <span>Send Payment To Merchant Account (پیمنٹ وصولی اکاؤنٹ)</span>
              </span>
              <span className="text-[10px] bg-red-100 text-red-800 font-semibold px-2 py-0.5 rounded">
                Verified Merchant
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* JazzCash Merchant Number */}
              <div className="bg-white p-2.5 rounded-xl border border-red-200/80 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-zinc-500 font-medium block">JazzCash Mobile Number:</span>
                  <span className="text-sm font-bold font-mono text-zinc-900 block select-all">
                    {gatewayPayload.merchantMobileNumber || '03001234567'}
                  </span>
                  <span className="text-[11px] text-red-700 font-medium block">
                    Title: {gatewayPayload.accountTitle || 'OmniStore Merchant'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(gatewayPayload.merchantMobileNumber || '03001234567');
                    alert('JazzCash Number Copied!');
                  }}
                  className="px-2.5 py-1.5 text-xs bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors cursor-pointer shrink-0"
                >
                  Copy
                </button>
              </div>

              {/* EasyPaisa Merchant Number */}
              {gatewayPayload.easypaisaNumber && (
                <div className="bg-white p-2.5 rounded-xl border border-emerald-200 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-zinc-500 font-medium block">EasyPaisa Mobile Number:</span>
                    <span className="text-sm font-bold font-mono text-zinc-900 block select-all">
                      {gatewayPayload.easypaisaNumber}
                    </span>
                    <span className="text-[11px] text-emerald-700 font-medium block">
                      Title: {gatewayPayload.easypaisaTitle || 'OmniStore Merchant'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(gatewayPayload.easypaisaNumber);
                      alert('EasyPaisa Number Copied!');
                    }}
                    className="px-2.5 py-1.5 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-lg transition-colors cursor-pointer shrink-0"
                  >
                    Copy
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab switch between payment modes */}
        <div className="flex items-center gap-1.5 mb-5 p-1 bg-zinc-100 rounded-lg text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('interactive')}
            className={`flex-1 py-1.5 text-center font-medium rounded-md transition-all cursor-pointer ${
              activeTab === 'interactive'
                ? 'bg-white text-zinc-900 shadow-xs'
                : 'text-zinc-500 hover:text-zinc-900'
            }`}
          >
            Direct Mobile Transfer / TID
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('official_form')}
            className={`flex-1 py-1.5 text-center font-medium rounded-md transition-all cursor-pointer ${
              activeTab === 'official_form'
                ? 'bg-white text-zinc-900 shadow-xs'
                : 'text-zinc-500 hover:text-zinc-900'
            }`}
          >
            Gateway Hosted API POST
          </button>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
            {errorMsg}
          </div>
        )}

        {activeTab === 'interactive' ? (
          <div className="space-y-4">
            {/* Payment Method Selector */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setPaymentMode('MWALLET')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  paymentMode === 'MWALLET'
                    ? 'border-zinc-900 bg-zinc-50/70 font-semibold'
                    : 'border-zinc-200 text-zinc-600 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Smartphone className="w-4 h-4 text-zinc-800" />
                  <span className="text-xs">Mobile Account / TID</span>
                </div>
                <span className="text-[11px] text-zinc-500 block font-normal">
                  JazzCash or EasyPaisa
                </span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMode('CARD')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  paymentMode === 'CARD'
                    ? 'border-zinc-900 bg-zinc-50/70 font-semibold'
                    : 'border-zinc-200 text-zinc-600 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-zinc-800" />
                  <span className="text-xs">Debit / Credit Card</span>
                </div>
                <span className="text-[11px] text-zinc-500 block font-normal">
                  Visa / Mastercard / PayPak
                </span>
              </button>
            </div>

            {paymentMode === 'MWALLET' ? (
              <div className="space-y-3.5 p-4 bg-zinc-50 rounded-xl border border-zinc-200">
                <div>
                  <label className="block text-xs font-semibold text-zinc-800 mb-1">
                    Your Mobile Number (کسٹمر کا موبائل نمبر)
                  </label>
                  <input
                    type="tel"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="03001234567"
                    className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono"
                  />
                  <span className="text-[11px] text-zinc-500 mt-0.5 block">
                    The phone number used to send the payment or receive SMS confirmation.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-800 mb-1">
                    Transaction ID / TID or MPIN (اختیاری ٹرانزیکشن ID)
                  </label>
                  <input
                    type="text"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="e.g. 0184920491 or PIN"
                    className="w-full px-3 py-2 bg-white border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono"
                  />
                  <span className="text-[11px] text-zinc-500 mt-0.5 block">
                    Enter the 10-digit TID from JazzCash/EasyPaisa SMS, or leave as default for automatic verification.
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-3 p-4 bg-zinc-50 rounded-xl border border-zinc-200 text-xs text-zinc-600">
                <p>Card payments are processed securely via JazzCash 3D-Secure 2.0 gateway.</p>
                <p className="text-[11px] text-zinc-500">
                  In live mode, clicking Pay redirects to the JazzCash bank hosted gateway and returns back to the store with HMAC-SHA256 signature verification.
                </p>
              </div>
            )}

            {/* Verification Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleSimulatePayment}
                disabled={isProcessing}
                className="w-full py-3.5 px-4 bg-red-600 hover:bg-red-700 disabled:bg-zinc-400 text-white font-semibold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying with Gateway & Dispatched PDF...</span>
                  </>
                ) : (
                  <>
                    <span>Verify & Confirm Payment {formatPrice(order.amount, 'PKR')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <p className="text-zinc-600">
              Below is the official HTTP POST form parameters constructed by the server, including the cryptographic HMAC-SHA256 Secure Hash.
            </p>
            {gatewayPayload ? (
              <div className="bg-zinc-900 text-zinc-100 p-4 rounded-xl font-mono text-[11px] overflow-x-auto max-h-60 space-y-1">
                <div>// POST Target: {gatewayPayload.postUrl}</div>
                {Object.entries(gatewayPayload.params).map(([key, val]) => (
                  <div key={key}>
                    <span className="text-amber-400">{key}</span>: &quot;{String(val)}&quot;
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-zinc-500">Generating payload...</div>
            )}
            <p className="text-[11px] text-zinc-500">
              When live credentials are set, this form is submitted automatically to the JazzCash transaction server.
            </p>
          </div>
        )}

        <div className="mt-5 pt-3 border-t border-zinc-100 flex items-center justify-between text-[11px] text-zinc-400">
          <span>Server-Side Gateway Integrity Checking</span>
          <span>State: {order.paymentStatus.toUpperCase()}</span>
        </div>

      </div>
    </div>
  );
};
