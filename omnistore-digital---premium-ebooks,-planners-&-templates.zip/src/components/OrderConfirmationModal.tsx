import React, { useState, useEffect } from 'react';
import { Order } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { CheckCircle2, Download, Mail, ShieldCheck, X, FileText, ArrowRight, ExternalLink, Clock, Copy, Check } from 'lucide-react';

interface OrderConfirmationModalProps {
  order: Order;
  onClose: () => void;
  onOpenSupport: () => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  onOpenSupport
}) => {
  const [downloadInfo, setDownloadInfo] = useState<any>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showEmailPreview, setShowEmailPreview] = useState(false);

  useEffect(() => {
    if (order.downloadToken) {
      fetch(`/api/downloads/info/${order.downloadToken}`)
        .then((r) => r.json())
        .then((d) => setDownloadInfo(d))
        .catch((err) => console.error('Failed to load download info:', err));
    }
  }, [order.downloadToken]);

  const handleDownload = () => {
    setIsDownloading(true);
    // Direct stream download from private storage endpoint
    window.location.href = `/api/downloads/${order.downloadToken}`;
    setTimeout(() => {
      setIsDownloading(false);
      // Refresh count
      if (order.downloadToken) {
        fetch(`/api/downloads/info/${order.downloadToken}`)
          .then((r) => r.json())
          .then((d) => setDownloadInfo(d));
      }
    }, 2000);
  };

  const copyDownloadUrl = () => {
    const fullUrl = `${window.location.origin}/api/downloads/${order.downloadToken}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[95vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Verified Success Header */}
        <div className="text-center pb-6 border-b border-zinc-100">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-xs">
            <CheckCircle2 className="w-8 h-8 stroke-2" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 block mb-1">
            Payment Verified & Order Fulfilled
          </span>
          <h2 className="text-2xl font-extrabold text-zinc-900 tracking-tight">
            Your Digital Download Is Ready
          </h2>
          <p className="text-xs text-zinc-500 mt-1 max-w-md mx-auto">
            Thank you, {order.customerName || 'valued customer'}. Your private access token has been generated and validated.
          </p>
        </div>

        {/* Download Box */}
        <div className="my-6 p-5 bg-zinc-900 rounded-2xl text-white shadow-lg space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center text-zinc-200 shrink-0">
                <FileText className="w-6 h-6 stroke-1.5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white line-clamp-1">{order.productTitle}</h4>
                <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                  <span>{downloadInfo?.fileFormat || 'PDF'}</span>
                  <span>·</span>
                  <span>{downloadInfo?.fileSize || 'Standard Release'}</span>
                </div>
              </div>
            </div>

            <div className="text-right text-xs text-zinc-400 shrink-0">
              <span className="block font-medium text-zinc-300">
                Downloads Used: {downloadInfo?.downloadsUsed ?? order.downloadCount} / {order.maxDownloads}
              </span>
              <span className="text-[11px] text-zinc-500">Expiring in 48 hours</span>
            </div>
          </div>

          {/* Big Action Download Button */}
          <button
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className="w-full py-3.5 px-4 bg-white hover:bg-zinc-100 text-zinc-900 font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-2" />
            <span>{isDownloading ? 'Starting Secure Download...' : 'Download Digital Product (PDF)'}</span>
          </button>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1">
            <span>Link secured with private HMAC signature</span>
            <button
              type="button"
              onClick={copyDownloadUrl}
              className="text-zinc-300 hover:text-white flex items-center gap-1 cursor-pointer underline"
            >
              {copiedLink ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedLink ? 'Link Copied' : 'Copy Direct Token URL'}</span>
            </button>
          </div>
        </div>

        {/* Itemized Order & Payment Receipt */}
        <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200 text-xs space-y-2 mb-6">
          <div className="flex justify-between py-1 border-b border-zinc-200">
            <span className="text-zinc-500">Order Number</span>
            <span className="font-mono font-semibold text-zinc-900">{order.id}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-zinc-200">
            <span className="text-zinc-500">Customer Delivery Email</span>
            <span className="font-medium text-zinc-900">{order.customerEmail}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-zinc-200">
            <span className="text-zinc-500">Amount Paid</span>
            <span className="font-bold text-zinc-900 tabular-nums">
              {formatPrice(order.amount, order.currency)}
            </span>
          </div>
          <div className="flex justify-between py-1 border-b border-zinc-200">
            <span className="text-zinc-500">Payment Gateway</span>
            <span className="font-semibold text-zinc-900 uppercase">
              {order.paymentMethod === 'jazzcash' ? 'JazzCash Official Gateway' : 'Cryptocurrency Invoice'}
            </span>
          </div>
          {order.paymentGatewayRef && (
            <div className="flex justify-between py-1 border-b border-zinc-200">
              <span className="text-zinc-500">Gateway Transaction Ref</span>
              <span className="font-mono text-zinc-700 text-[11px]">{order.paymentGatewayRef}</span>
            </div>
          )}
          <div className="flex justify-between py-1">
            <span className="text-zinc-500">Status</span>
            <span className="text-emerald-700 font-bold uppercase tracking-wider text-[11px]">
              VERIFIED & DELIVERED
            </span>
          </div>
        </div>

        {/* Email Dispatched Notice */}
        <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start gap-2.5 mb-6">
          <Mail className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="font-semibold">Order confirmation email dispatched!</div>
            <p className="text-[11px] text-blue-800 mt-0.5 leading-relaxed">
              A copy of your receipt and expiring download link has been sent to <strong>{order.customerEmail}</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowEmailPreview(!showEmailPreview)}
              className="mt-1.5 text-[11px] font-semibold text-blue-700 hover:text-blue-900 underline cursor-pointer"
            >
              {showEmailPreview ? 'Hide email receipt preview' : 'View dispatched email copy'}
            </button>
          </div>
        </div>

        {/* Email Receipt Preview (Accordian) */}
        {showEmailPreview && (
          <div className="p-4 bg-white border border-zinc-200 rounded-xl text-xs mb-6 shadow-inner">
            <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-2">
              HTML Email Preview (Sent to {order.customerEmail})
            </div>
            <div className="bg-zinc-50 p-4 rounded-lg border border-zinc-200 space-y-2">
              <p className="font-bold text-zinc-900">Subject: Your Digital Download: {order.productTitle} ({order.id})</p>
              <p>Hi {order.customerName || 'Customer'},</p>
              <p className="text-zinc-600">Your payment of {formatPrice(order.amount, order.currency)} has been verified.</p>
              <div className="p-3 bg-zinc-900 text-white rounded text-center my-2 font-semibold">
                Download Link: /api/downloads/{order.downloadToken}
              </div>
              <p className="text-[11px] text-zinc-500">Expiry: 48 Hours · Max 5 downloads</p>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onOpenSupport}
            className="text-xs text-zinc-500 hover:text-zinc-900 underline cursor-pointer"
          >
            Need help or refund? Contact Support
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-zinc-700 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors cursor-pointer"
          >
            Back to Store
          </button>
        </div>

      </div>
    </div>
  );
};
