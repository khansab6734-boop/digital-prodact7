import React, { useState, useEffect } from 'react';
import { Order, CryptoCurrency, CryptoDetails } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { X, Copy, Check, Clock, ShieldCheck, RefreshCw, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';

interface CryptoPaymentModalProps {
  order: Order;
  onClose: () => void;
  onPaymentSuccess: (paidOrder: Order) => void;
}

export const CryptoPaymentModal: React.FC<CryptoPaymentModalProps> = ({
  order,
  onClose,
  onPaymentSuccess
}) => {
  const [selectedCoin, setSelectedCoin] = useState<CryptoCurrency>('USDT_TRC20');
  const [cryptoDetails, setCryptoDetails] = useState<CryptoDetails | null>(order.cryptoDetails || null);
  const [qrSvg, setQrSvg] = useState<string>('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [copiedAmount, setCopiedAmount] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes in seconds

  // Initialize or fetch crypto invoice
  useEffect(() => {
    async function createInvoice() {
      setIsLoading(true);
      try {
        const res = await fetch('/api/payments/crypto/create-invoice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId: order.id,
            cryptoCurrency: selectedCoin
          })
        });
        const data = await res.json();
        if (res.ok) {
          setCryptoDetails(data.cryptoDetails);
          setQrSvg(data.qrSvg);
        }
      } catch (err) {
        console.error('Failed to create crypto invoice:', err);
      } finally {
        setIsLoading(false);
      }
    }
    createInvoice();
  }, [order.id, selectedCoin]);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Poll status from server
  useEffect(() => {
    if (!order.id) return;
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/payments/crypto/status/${order.id}`);
        const data = await res.json();
        if (data.cryptoDetails) {
          setCryptoDetails(data.cryptoDetails);
        }
        if (data.paymentStatus === 'paid') {
          clearInterval(interval);
          const updatedOrderRes = await fetch(`/api/orders/${order.id}`);
          const updatedData = await updatedOrderRes.json();
          if (updatedData.order) {
            onPaymentSuccess(updatedData.order);
          }
        }
      } catch (err) {
        console.error('Error polling crypto status:', err);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [order.id, onPaymentSuccess]);

  const copyToClipboard = (text: string, type: 'address' | 'amount') => {
    navigator.clipboard.writeText(text);
    if (type === 'address') {
      setCopiedAddress(true);
      setTimeout(() => setCopiedAddress(false), 2000);
    } else {
      setCopiedAmount(true);
      setTimeout(() => setCopiedAmount(false), 2000);
    }
  };

  // Test mode simulation of blockchain confirmation block
  const handleSimulateConfirmation = async () => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/payments/crypto/simulate-confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: order.id })
      });
      const data = await res.json();
      if (data.isPaid && data.order) {
        onPaymentSuccess(data.order);
      } else if (data.order && data.order.cryptoDetails) {
        setCryptoDetails(data.order.cryptoDetails);
      }
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timeFormatted = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

  const coinLabels: Record<CryptoCurrency, { name: string; network: string }> = {
    USDT_TRC20: { name: 'USDT', network: 'TRON TRC-20' },
    BTC: { name: 'Bitcoin', network: 'BTC Native SegWit' },
    ETH: { name: 'Ethereum', network: 'ERC-20' },
    SOL: { name: 'Solana', network: 'Solana Mainnet' }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[95vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-100">
          <div>
            <h3 className="text-base font-bold text-zinc-900 leading-tight">
              Cryptocurrency Payment Invoice
            </h3>
            <p className="text-xs text-zinc-500">
              Order: <span className="font-mono text-zinc-700">{order.id}</span>
            </p>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-700 bg-zinc-100 px-3 py-1.5 rounded-lg tabular-nums">
            <Clock className="w-3.5 h-3.5 text-zinc-500" />
            <span>{timeFormatted}</span>
          </div>
        </div>

        {/* Currency Tabs */}
        <div className="grid grid-cols-4 gap-1.5 mb-5 p-1 bg-zinc-100 rounded-lg text-xs">
          {(['USDT_TRC20', 'BTC', 'ETH', 'SOL'] as CryptoCurrency[]).map((coin) => (
            <button
              key={coin}
              type="button"
              onClick={() => setSelectedCoin(coin)}
              className={`py-1.5 text-center font-semibold rounded-md transition-all cursor-pointer ${
                selectedCoin === coin
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              {coinLabels[coin].name}
            </button>
          ))}
        </div>

        {isLoading || !cryptoDetails ? (
          <div className="py-12 flex flex-col items-center justify-center text-zinc-400">
            <RefreshCw className="w-8 h-8 animate-spin mb-2" />
            <span className="text-xs font-medium">Generating encrypted payment invoice...</span>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Amount and Address Summary Card */}
            <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                  Amount to Transfer
                </span>
                <span className="text-xs text-zinc-400">Network: {coinLabels[selectedCoin].network}</span>
              </div>

              <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-zinc-200 mb-3">
                <div>
                  <span className="text-lg font-bold text-zinc-900 font-mono">
                    {cryptoDetails.cryptoAmount} {coinLabels[selectedCoin].name}
                  </span>
                  <span className="text-xs text-zinc-500 ml-2">
                    (approx. {formatPrice(order.amount, order.currency)})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(String(cryptoDetails.cryptoAmount), 'amount')}
                  className="px-2.5 py-1 text-xs font-medium text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-md transition-colors flex items-center gap-1 cursor-pointer"
                >
                  {copiedAmount ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAmount ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Wallet Address */}
              <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-zinc-200">
                <div className="min-w-0 mr-2">
                  <span className="text-[11px] text-zinc-400 block mb-0.5">Deposit Wallet Address:</span>
                  <span className="text-xs font-mono text-zinc-800 break-all select-all">
                    {cryptoDetails.walletAddress}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(cryptoDetails.walletAddress, 'address')}
                  className="px-2.5 py-1 text-xs font-medium text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-md transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAddress ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* QR Code and Instructions */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
              <div className="sm:col-span-5 flex justify-center">
                <div
                  className="w-40 h-40 border border-zinc-200 rounded-xl overflow-hidden shadow-xs flex items-center justify-center bg-white"
                  dangerouslySetInnerHTML={{ __html: qrSvg }}
                />
              </div>

              <div className="sm:col-span-7 space-y-2 text-xs text-zinc-600">
                <p className="font-semibold text-zinc-900">Payment Instructions:</p>
                <ol className="list-decimal list-inside space-y-1 text-zinc-600 text-[11px] leading-relaxed">
                  <li>Scan the QR code or copy the address above.</li>
                  <li>Send exact amount on the <strong>{coinLabels[selectedCoin].network}</strong> network.</li>
                  <li>Confirmations required: <strong>{cryptoDetails.requiredConfirmations} block(s)</strong>.</li>
                  <li>Your download is automatically fulfilled once verified.</li>
                </ol>
              </div>
            </div>

            {/* Live Confirmation Status Box */}
            <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <RefreshCw className="w-4 h-4 text-zinc-500 animate-spin" />
                <div>
                  <span className="text-xs font-semibold text-zinc-900 block">
                    Listening for blockchain transactions...
                  </span>
                  <span className="text-[11px] text-zinc-500">
                    Network Confirmations: {cryptoDetails.confirmations} of {cryptoDetails.requiredConfirmations} confirmed
                  </span>
                </div>
              </div>

              <span className="text-xs font-mono font-medium text-zinc-600 bg-white px-2 py-1 rounded border border-zinc-200">
                {cryptoDetails.status.toUpperCase()}
              </span>
            </div>

            {/* Sandbox Simulation Button for Testing */}
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-amber-900">Sandbox Test Mode</span>
                <span className="text-[10px] text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">Development</span>
              </div>
              <p className="text-[11px] text-amber-800 mb-3 leading-relaxed">
                Test the automated blockchain webhook and server confirmation flow without sending actual cryptocurrency.
              </p>
              <button
                type="button"
                onClick={handleSimulateConfirmation}
                disabled={isSimulating}
                className="w-full py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSimulating ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Mining block confirmation...</span>
                  </>
                ) : (
                  <>
                    <span>Simulate Blockchain Block Confirmation (+1)</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>

          </div>
        )}

        <div className="mt-5 pt-3 border-t border-zinc-100 flex items-center justify-between text-[11px] text-zinc-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-zinc-600" />
            <span>Authenticated Server-Side IPN Webhooks</span>
          </div>
          <span>Zero Frontend Private Keys</span>
        </div>

      </div>
    </div>
  );
};
