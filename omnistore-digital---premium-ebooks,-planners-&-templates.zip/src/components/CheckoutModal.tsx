import React, { useState } from 'react';
import { Product, Currency, PaymentMethod, Order } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { X, ShieldCheck, Mail, User, Phone, CheckCircle2, ArrowRight, Lock } from 'lucide-react';

interface CheckoutModalProps {
  product: Product;
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  onClose: () => void;
  onOrderCreated: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  product,
  currency,
  onCurrencyChange,
  onClose,
  onOrderCreated
}) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(
    currency === 'PKR' ? 'jazzcash' : 'crypto'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const currentPrice = currency === 'PKR' ? product.pricePKR : product.priceUSD;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address to receive your download link.');
      return;
    }
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerEmail: email.trim(),
          customerName: name.trim() || email.split('@')[0],
          customerPhone: phone.trim() || undefined,
          productId: product.id,
          currency,
          paymentMethod
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to initiate checkout order');
      }

      onOrderCreated(data.order);
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred during checkout setup.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[95vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1">
            <Lock className="w-3.5 h-3.5 text-zinc-700" />
            <span>Secure Instant Checkout</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-zinc-900 tracking-tight">
            Complete Your Digital Order
          </h2>
          <p className="text-xs text-zinc-500 mt-1">
            Your private download link will be generated and emailed instantly after payment verification.
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
            {errorMsg}
          </div>
        )}

        {/* Order Summary Box */}
        <div className="p-4 rounded-xl bg-zinc-50 border border-zinc-200 mb-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-zinc-200 overflow-hidden shrink-0 border border-zinc-300">
                <img
                  src={product.coverImage}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-zinc-900 line-clamp-1">{product.title}</h4>
                <p className="text-xs text-zinc-500">{product.fileFormat} · {product.pagesCount} Pages</p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-sm font-bold text-zinc-900 tabular-nums">
                {formatPrice(currentPrice, currency)}
              </span>
              <div className="flex items-center gap-1 justify-end mt-0.5">
                <button
                  type="button"
                  onClick={() => onCurrencyChange(currency === 'PKR' ? 'USD' : 'PKR')}
                  className="text-[11px] text-zinc-500 hover:text-zinc-900 underline cursor-pointer"
                >
                  Switch to {currency === 'PKR' ? 'USD ($)' : 'PKR (Rs)'}
                </button>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Email input (Mandatory for automated delivery) */}
          <div>
            <label className="block text-xs font-semibold text-zinc-800 mb-1">
              Delivery Email Address <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@example.com"
                className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900 placeholder-zinc-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 transition-all"
              />
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">
              We never spam. The download access token and purchase receipt will be delivered here.
            </span>
          </div>

          {/* Full Name & Phone inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-800 mb-1">
                Full Name (Optional)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Asim Khan"
                  className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900 placeholder-zinc-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-800 mb-1">
                Phone Number (Optional)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0300 1234567"
                  className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900 placeholder-zinc-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 transition-all"
                />
              </div>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-semibold text-zinc-800 mb-2">
              Select Payment Method <span className="text-red-500">*</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* JazzCash option */}
              <label
                onClick={() => setPaymentMethod('jazzcash')}
                className={`relative p-3.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  paymentMethod === 'jazzcash'
                    ? 'border-zinc-900 bg-zinc-50/50 shadow-xs'
                    : 'border-zinc-200 hover:border-zinc-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-sm text-zinc-900 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-600 inline-block"></span>
                      JazzCash & EasyPaisa
                    </span>
                    {paymentMethod === 'jazzcash' && (
                      <CheckCircle2 className="w-4 h-4 text-zinc-900" />
                    )}
                  </div>
                  <p className="text-[11px] text-zinc-500 leading-tight">
                    Direct mobile account transfer to merchant number, USSD push, or Debit Card.
                  </p>
                </div>
                <div className="mt-2 text-[10px] text-zinc-400 font-medium">
                  Currency: PKR (Pakistani Rupees)
                </div>
              </label>

              {/* Cryptocurrency option */}
              <label
                onClick={() => setPaymentMethod('crypto')}
                className={`relative p-3.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  paymentMethod === 'crypto'
                    ? 'border-zinc-900 bg-zinc-50/50 shadow-xs'
                    : 'border-zinc-200 hover:border-zinc-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-sm text-zinc-900 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
                      Cryptocurrency
                    </span>
                    {paymentMethod === 'crypto' && (
                      <CheckCircle2 className="w-4 h-4 text-zinc-900" />
                    )}
                  </div>
                  <p className="text-[11px] text-zinc-500 leading-tight">
                    Pay with USDT (TRC-20), Bitcoin, Ethereum, or Solana with instant on-chain verification.
                  </p>
                </div>
                <div className="mt-2 text-[10px] text-zinc-400 font-medium">
                  Global · Multi-Network · Low Fees
                </div>
              </label>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-zinc-900 hover:bg-zinc-800 disabled:bg-zinc-400 text-white font-semibold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Generating Payment Session...</span>
              ) : (
                <>
                  <span>
                    Proceed to {paymentMethod === 'jazzcash' ? 'JazzCash Checkout' : 'Crypto Invoice'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 text-xs text-zinc-400 text-center">
            <ShieldCheck className="w-4 h-4" />
            <span>Strict server-side verification · PDF link never released without confirmed payment</span>
          </div>

        </form>

      </div>
    </div>
  );
};
