import React from 'react';
import { Product, Currency } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { X, Check, Download, ShieldCheck, FileText, ArrowRight, Clock, Smartphone, Layers } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  currency: Currency;
  onClose: () => void;
  onBuyNow: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currency,
  onClose,
  onBuyNow
}) => {
  if (!product) return null;

  const currentPrice = currency === 'PKR' ? product.pricePKR : product.priceUSD;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-zinc-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-zinc-200 shadow-2xl z-10">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 hover:bg-zinc-100 text-zinc-500 hover:text-zinc-900 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          
          {/* Left Column: Visual Gallery & File Specifications (5 cols) */}
          <div className="md:col-span-5 bg-zinc-50 p-6 sm:p-8 border-b md:border-b-0 md:border-r border-zinc-200 flex flex-col justify-between">
            <div>
              <div className="aspect-4/3 rounded-xl overflow-hidden bg-white border border-zinc-200 shadow-xs mb-6">
                <img
                  src={product.coverImage}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Technical Specifications */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                  File Specifications
                </h4>
                
                <div className="text-xs text-zinc-600 space-y-2">
                  <div className="flex justify-between py-1.5 border-b border-zinc-200">
                    <span className="text-zinc-500">Format</span>
                    <span className="font-semibold text-zinc-900">{product.fileFormat}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-zinc-200">
                    <span className="text-zinc-500">File Size</span>
                    <span className="font-semibold text-zinc-900">{product.fileSize}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-zinc-200">
                    <span className="text-zinc-500">Pages / Length</span>
                    <span className="font-semibold text-zinc-900">{product.pagesCount} Pages</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-zinc-200">
                    <span className="text-zinc-500">Delivery Method</span>
                    <span className="font-semibold text-zinc-900">Instant PDF Delivery</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-zinc-200 text-xs text-zinc-500 space-y-1.5">
              <div className="flex items-center gap-2 text-zinc-700">
                <ShieldCheck className="w-4 h-4 text-zinc-800" />
                <span>Verified Private Storage Links</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                Downloaded links are HMAC-signed and strictly access controlled to protect digital ownership.
              </p>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module (7 cols) */}
          <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Unboxed category & metadata */}
              <div className="flex items-center gap-2 text-xs text-zinc-500 mb-2">
                <span className="font-semibold text-zinc-900 uppercase tracking-wider">{product.category}</span>
                <span aria-hidden="true">·</span>
                <span>Immediate Download</span>
              </div>

              <h2 className="text-2xl font-bold text-zinc-900 tracking-tight leading-snug">
                {product.title}
              </h2>

              <p className="mt-2 text-sm text-zinc-600 leading-relaxed font-medium">
                {product.tagline}
              </p>

              {/* Price Banner */}
              <div className="my-6 p-4 bg-zinc-50 rounded-xl border border-zinc-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-zinc-500 block">
                    Instant Download Price
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-extrabold text-zinc-900 tabular-nums">
                      {formatPrice(currentPrice, currency)}
                    </span>
                    <span className="text-xs text-zinc-500">
                      {currency === 'PKR' ? `(~${formatPrice(product.priceUSD, 'USD')})` : `(~${formatPrice(product.pricePKR, 'PKR')})`}
                    </span>
                  </div>
                </div>

                <div className="text-right text-xs text-zinc-500">
                  <span className="block font-medium text-zinc-700">JazzCash & Crypto</span>
                  <span className="text-[11px]">Zero hidden fees</span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-3 mb-6">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                  Overview
                </h4>
                <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* What's Included */}
              <div className="space-y-2 mb-6">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                  What&apos;s Included In This Download
                </h4>
                <div className="grid grid-cols-1 gap-2 pt-1">
                  {product.whatsIncluded?.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-zinc-700">
                      <div className="w-4 h-4 rounded-full bg-zinc-100 flex items-center justify-center shrink-0 mt-0.5 text-zinc-900">
                        <Check className="w-3 h-3 stroke-2" />
                      </div>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Features */}
              {product.features && product.features.length > 0 && (
                <div className="space-y-2 mb-6">
                  <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                    Core Capabilities
                  </h4>
                  <ul className="text-xs text-zinc-600 space-y-1 list-disc list-inside">
                    {product.features.map((feat, idx) => (
                      <li key={idx}>{feat}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Bottom Buy CTA Strip */}
            <div className="pt-6 border-t border-zinc-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-zinc-500 text-center sm:text-left">
                <span>Includes PDF + Lifetime Free Updates</span>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onBuyNow(product);
                }}
                className="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-zinc-900 hover:bg-zinc-800 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Buy Now · {formatPrice(currentPrice, currency)}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
