import React from 'react';
import { Currency } from '../types.js';
import { ShieldCheck, Search } from 'lucide-react';

interface HeaderProps {
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  onOpenTracker: () => void;
  onOpenSupport: () => void;
  onOpenAdmin: () => void;
  onFilterCategory?: (category: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currency,
  onCurrencyChange,
  onOpenTracker,
  onOpenSupport,
  onOpenAdmin,
  onFilterCategory
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
            if (onFilterCategory) onFilterCategory('All');
          }}
          className="text-lg font-bold tracking-tight text-zinc-900 whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 bg-zinc-900 rounded-sm"></span>
          <span>OmniStore Digital</span>
        </a>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-600">
          <button
            onClick={() => {
              if (onFilterCategory) onFilterCategory('All');
              const el = document.getElementById('catalog-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Catalog
          </button>
          <button
            onClick={() => {
              if (onFilterCategory) onFilterCategory('eBooks & Handbooks');
              const el = document.getElementById('catalog-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-zinc-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Guides & eBooks
          </button>
          <button
            onClick={onOpenTracker}
            className="hover:text-zinc-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Track Order
          </button>
          <button
            onClick={onOpenSupport}
            className="hover:text-zinc-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Support
          </button>
          <button
            onClick={onOpenAdmin}
            className="hover:text-zinc-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Admin Portal
          </button>
        </nav>

        {/* Zone 3: 1 primary action / Currency Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center bg-zinc-100 p-0.5 rounded-lg border border-zinc-200">
            <button
              onClick={() => onCurrencyChange('USD')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                currency === 'USD'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              USD ($)
            </button>
            <button
              onClick={() => onCurrencyChange('PKR')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                currency === 'PKR'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              PKR (Rs)
            </button>
          </div>

          <button
            onClick={() => {
              const el = document.getElementById('catalog-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hidden sm:inline-flex px-4 py-2 text-xs font-medium text-white bg-zinc-900 rounded-lg hover:bg-zinc-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Explore Store
          </button>
        </div>

      </div>
    </header>
  );
};
