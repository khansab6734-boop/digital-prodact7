import React, { useState } from 'react';
import { Product, Currency } from '../types.js';
import { formatPrice } from '../utils/currency.js';
import { FileText, ArrowRight, Star } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  currency: Currency;
  onSelect: (product: Product) => void;
  onInstantBuy: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  onSelect,
  onInstantBuy
}) => {
  const [imageError, setImageError] = useState(false);
  const currentPrice = currency === 'PKR' ? product.pricePKR : product.priceUSD;

  return (
    <div
      onClick={() => onSelect(product)}
      className="group flex flex-col bg-white rounded-xl border border-zinc-200 overflow-hidden hover:border-zinc-300 hover:shadow-md transition-all duration-200 cursor-pointer"
    >
      {/* Product Image slot taking 65-70% height with solid neutral framing */}
      <div className="relative aspect-4/3 w-full bg-zinc-100 overflow-hidden flex items-center justify-center">
        {!imageError && product.coverImage ? (
          <img
            src={product.coverImage}
            alt={product.title}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-zinc-400 bg-zinc-100">
            <FileText className="w-12 h-12 stroke-1 mb-2 text-zinc-500" />
            <span className="text-xs font-medium text-zinc-500 text-center">{product.title}</span>
          </div>
        )}

        {/* Quiet format indicator */}
        <div className="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded-sm">
          {product.fileFormat}
        </div>
      </div>

      {/* Card Content & Metadata */}
      <div className="p-5 flex flex-col flex-1 justify-between">
        <div>
          {/* Unboxed metadata with typographic separator */}
          <div className="flex items-center gap-1.5 text-xs text-zinc-500 mb-1.5">
            <span className="font-medium text-zinc-700">{product.category}</span>
            <span aria-hidden="true">·</span>
            <span>{product.pagesCount} Pages</span>
            <span aria-hidden="true">·</span>
            <span>{product.fileSize}</span>
          </div>

          <h3 className="text-base font-semibold text-zinc-900 group-hover:text-zinc-700 transition-colors line-clamp-1">
            {product.title}
          </h3>

          <p className="mt-1.5 text-xs text-zinc-500 line-clamp-2 leading-relaxed">
            {product.tagline || product.description}
          </p>
        </div>

        {/* Bottom Bar: Tabular Price + Action Button */}
        <div className="mt-5 pt-4 border-t border-zinc-100 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium">Price</span>
            <span className="text-base font-bold text-zinc-900 tabular-nums">
              {formatPrice(currentPrice, currency)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onInstantBuy(product);
              }}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-zinc-900 hover:bg-zinc-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1"
            >
              <span>Buy Now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
