import React from 'react';
import { Search, Download, ShieldCheck, Zap } from 'lucide-react';
import { ProductCategory } from '../types.js';

interface HeroProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: string;
  onCategoryChange: (cat: string) => void;
  categories: ProductCategory[];
}

export const Hero: React.FC<HeroProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  categories
}) => {
  return (
    <div className="bg-white border-b border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-10">
        
        {/* Unboxed editorial kicker */}
        <div className="flex items-center gap-2 text-xs font-medium text-zinc-500 uppercase tracking-wider mb-4">
          <span>Digital Publishing & Software Handbooks</span>
          <span aria-hidden="true">·</span>
          <span>Instant Download</span>
          <span aria-hidden="true">·</span>
          <span>Multi-Currency PKR & USD</span>
        </div>

        {/* Hero headline with balanced text */}
        <div className="max-w-3xl mb-8">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-zinc-900 tracking-tight leading-tight text-balance">
            Digital tools engineered for focus, wealth building, and deep engineering.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-zinc-600 leading-relaxed max-w-2xl">
            Curated eBooks, interactive planners, and architectural frameworks. Download immediately upon verified server payment through JazzCash or Cryptocurrency.
          </p>
        </div>

        {/* Search bar and interactive filter controls */}
        <div className="space-y-4">
          <div className="relative max-w-xl">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search planners, eBooks, templates, system handbooks..."
              className="w-full pl-11 pr-4 py-3 bg-zinc-50 hover:bg-white focus:bg-white border border-zinc-200 rounded-xl text-sm text-zinc-900 placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 transition-all shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-xs font-medium text-zinc-400 hover:text-zinc-700 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {/* Interactive filter buttons / segmented controls */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none pt-2">
            <button
              onClick={() => onCategoryChange('All')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCategory === 'All'
                  ? 'bg-zinc-900 text-white shadow-xs'
                  : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200 hover:text-zinc-900'
              }`}
            >
              All Products
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => onCategoryChange(cat)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-zinc-900 text-white shadow-xs'
                    : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200 hover:text-zinc-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Claim-to-proof adjacency strip */}
        <div className="mt-8 pt-6 border-t border-zinc-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-zinc-700 shrink-0" />
            <span>Instant PDF link generated upon payment</span>
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-zinc-700 shrink-0" />
            <span>Secure private token storage (no public URL)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-zinc-800">JazzCash</span>
            <span>Official Pakistan gateway verification</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-zinc-800">Crypto</span>
            <span>USDT, BTC, ETH & SOL supported</span>
          </div>
        </div>

      </div>
    </div>
  );
};
