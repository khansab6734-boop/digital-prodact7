import { Currency } from '../types.js';

export function formatPrice(amount: number, currency: Currency): string {
  if (currency === 'PKR') {
    return `Rs ${Math.round(amount).toLocaleString()}`;
  }
  return `$${amount.toFixed(2)}`;
}

export function convertPrice(amount: number, from: Currency, to: Currency, rate: number = 278): number {
  if (from === to) return amount;
  if (from === 'USD' && to === 'PKR') {
    return Math.round(amount * rate);
  }
  return Number((amount / rate).toFixed(2));
}
